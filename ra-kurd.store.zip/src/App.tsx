/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { 
  Home, 
  LayoutGrid, 
  Package, 
  Settings, 
  Search, 
  Bell, 
  User,
  ChevronRight,
  Download,
  FileDown,
  Info,
  Shield,
  ShieldCheck,
  Zap,
  Globe,
  Moon,
  Sun,
  Send,
  Instagram,
  Check,
  Palette,
  X,
  Star,
  ExternalLink,
  History,
  Layout,
  ShieldAlert,
  Apple,
  Bot,
  Upload,
  Lock,
  Copy
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

// --- Constants ---
const LOGO_URL = "https://i.postimg.cc/PrwCMc4h/unnamed-17.jpg";

// --- Types ---
type Tab = "home" | "ios" | "apk" | "setting";
type Language = "en" | "ar" | "ku_ba" | "ku_so";

interface AppItem {
  id: string;
  name: string;
  category: string;
  size: string;
  version: string;
  description: string;
  updateLog: string;
  icon: string;
  banner: string;
  rating: number;
  downloads: string;
  author?: string;
  directLink?: string;
  ipaLink?: string;
  warning?: string;
  platform: 'ios' | 'android';
}

interface AppState {
  isDarkMode: boolean;
  language: Language;
  accentColor: string;
}

// --- Mock Data ---
const APPS: AppItem[] = [
  {
    id: "roblox-delta",
    name: "Roblox Delta",
    category: "Games",
    size: "123 MB",
    version: "v1.0",
    description: "Roblox Delta executor edition for iOS. Enjoy modified features, script execution support, and enhanced gameplay controls.",
    updateLog: "✨ تایبەتمەندی:\n\n• Roblox Delta Executor for iOS\n• Script execution support & custom menu\n• Smooth performance & anti-cheat bypass",
    icon: "https://i.postimg.cc/Dyxd1V85/download.jpg",
    banner: "https://picsum.photos/seed/robloxdelta/600/300",
    rating: 5.0,
    downloads: "200K+",
    author: "Yousif.duski",
    ipaLink: "https://url-shortener.me/OJX8",
    directLink: "itms-services://?action=download-manifest&url=https://applejr.net/download/2a12b934-1022-458e-944b-88245efab8b0.plist",
    platform: 'ios'
  },
  {
    id: "resident-evil-village",
    name: "Resident Evil Village",
    category: "Games",
    size: "1 GB",
    version: "v1.0",
    description: "Experience survival horror like never before in Resident Evil Village for iOS. Immersive gameplay and high quality graphics.",
    updateLog: "✨ تایبەتمەندی:\n\n• Resident Evil Village for iOS\n• Unlocked full game performance\n• Optimized graphics & smooth controls",
    icon: "https://i.postimg.cc/J0wj4mY4/a-Nh-ZPHi-QG2CU-icon.png",
    banner: "https://picsum.photos/seed/revillage/600/300",
    rating: 5.0,
    downloads: "50K+",
    author: "Yousif.duski",
    ipaLink: "https://url-shortener.me/OJX1",
    directLink: "itms-services://?action=download-manifest&url=https://bot.ipasign.cc/dl/20260725055036882b3c7/aNhZPHiQG2CU.plist",
    platform: 'ios'
  },
  {
    id: "streamchamp",
    name: "StreamChamp",
    category: "Tools",
    size: "28.5 MB",
    version: "v1.0",
    description: "Livestreaming app for iOS. Stream live video to Twitch, YouTube, Facebook, and custom RTMP endpoints with custom overlays and controls.",
    updateLog: "✨ تایبەتمەندی:\n\n• StreamChamp for iOS\n• Live streaming app with custom overlay support\n• HD quality streaming unlocked",
    icon: "https://i.postimg.cc/25DScMZ1/photo-2026-07-24-23-33-46.jpg",
    banner: "https://picsum.photos/seed/streamchamp/600/300",
    rating: 4.9,
    downloads: "100K+",
    author: "Yousif.duski",
    ipaLink: "https://shrinkme.click/7SsXQY",
    directLink: "itms-services://?action=download-manifest&url=https://ipa.ipasign.cc/manifest/ccbc46aa9cd5.plist",
    platform: 'ios'
  },
  {
    id: "spotify",
    name: "Spotify Premium",
    category: "Media",
    size: "118 MB",
    version: "Premium",
    description: "Listen to millions of songs and podcasts without ads, with unlimited skips and high quality audio.",
    updateLog: "✨ تایبەتمەندی:\n\n• Spotify Premium Unlocked\n• No Ads (بێ ڕیکلام)\n• Unlimited Skips (تێپەڕاندنا بێسنوور)\n• Very High Quality Audio Unlocked",
    icon: "https://i.postimg.cc/pTXTYky8/photo-2026-07-08-17-08-44.jpg",
    banner: "https://picsum.photos/seed/spotify/600/300",
    rating: 4.9,
    downloads: "500K+",
    author: "Yousif.duski",
    ipaLink: "https://shrinkme.click/wXqPoeQ",
    directLink: "itms-services://?action=download-manifest&url=https://bot.ipasign.cc/dl/202607250317147730302/LTcqaknvTKeA.plist",
    platform: 'ios'
  },
  {
    id: "alight-motion",
    name: "Alight Motion",
    category: "Media",
    size: "98.3 MB",
    version: "v6.2.53",
    description: "Professional motion graphics, animation, visual effects, and video editing for mobile devices. Fully unlocked.",
    updateLog: "✨ تایبەتمەندی:\n\n• Alight Motion Pro Unlocked\n• No Watermark\n• All Premium Effects & Assets Unlocked",
    icon: "https://i.postimg.cc/ZqDDFrBs/photo-2026-06-30-15-23-25.jpg",
    banner: "https://picsum.photos/seed/alightmotion/600/300",
    rating: 4.9,
    downloads: "450K+",
    author: "Yousif.duski",
    ipaLink: "https://shrinkme.click/D5jPw",
    directLink: "itms-services://?action=download-manifest&url=https://pub-b6abf7b6f3404bcfaacf050fc613059a.r2.dev/2c2ca2e7-2df2-46c9-897d-1eb6d274d0da/manifest.plist",
    platform: 'ios'
  },
  {
    id: "hill-climb",
    name: "Hill Climb Racing",
    category: "Games",
    size: "125 MB",
    version: "Mod",
    description: "Classic physics-based driving game with modified features.",
    updateLog: "✨ تایبەتمەندی:\n\n• Hill Climb Racing Mod\n• Unlimited Coins & Gems Unlocked",
    icon: "https://i.postimg.cc/QtXv0X0F/photo-2026-06-30-15-22-58.jpg",
    banner: "https://picsum.photos/seed/hillclimb/600/300",
    rating: 4.9,
    downloads: "200K+",
    author: "Yousif.duski",
    ipaLink: "https://shrinkme.click/9R5v0I",
    directLink: "itms-services://?action=download-manifest&url=https://ipa.ipasign.cc/manifest/5df564cf8e7f.plist",
    platform: 'ios'
  },
  {
    id: "racing-in-car-2021",
    name: "racing in car 2021",
    category: "Games",
    size: "216.5 MB",
    version: "v5.8",
    description: "Realistic driving simulation with traffic and high-quality graphics. Fully unlocked with unlimited coins.",
    updateLog: "✨ تایبەتمەندی:\n\n• Racing in Car 2021 IPA v5.8\n• (Unlimited Coins/Multiplayer Unlocked) iOS",
    icon: "https://i.postimg.cc/FsVgBNpr/photo-2026-05-12-22-42-03.jpg",
    banner: "https://picsum.photos/seed/racingincar/600/300",
    rating: 4.8,
    downloads: "80K+",
    author: "Yousif.duski",
    ipaLink: "https://shrinkme.click/YxjW",
    directLink: "https://url-shortener.me/M3V3",
    platform: 'ios'
  },
  {
    id: "car-parking-mod",
    name: "Car Parking",
    category: "Games",
    size: "1.3 GB",
    version: "Mod",
    description: "Experience the ultimate car parking simulation with fully unlocked features and free in-game purchases.",
    updateLog: "✨ تایبەتمەندی:\n\n✅ .ئەڤ یارییە هاککرییە! تەنها بچۆ د مارکێتێ دا و دەست بکە ب کڕینا زێڕ و پارەی ب بێ بەرامبەر. هەرچەندە تو کلیکێ ل سەر زێدەکردنێ بکەی، دێ پتر بۆ تە هێن.",
    icon: "https://i.postimg.cc/jdQDyT1Q/photo-2026-05-08-21-43-59.jpg",
    banner: "https://picsum.photos/seed/carparking/600/300",
    rating: 4.9,
    downloads: "100K+",
    author: "Yousif.duski",
    ipaLink: "https://shrinkme.click/PFxj5",
    directLink: "https://url-shortener.me/M05I",
    platform: 'ios'
  },
  {
    id: "video-star-pro",
    name: "video Star pro",
    category: "Media",
    size: "188 MB",
    version: "Premium",
    description: "Create professional music videos with Video Star Pro. Fully unlocked features including all codes, transforms, and paid packs.",
    updateLog: "✨ تایبەتمەندی:\n\n✅ .کۆد: هەمی کۆد ب دروستی کار دکەن.\n✅ .ترانسفۆرم (Transform): هەمی کۆد دهێنە خاندن\n✅ .ئیفێکتێ ئاگرى (Fire Effect): ب بێ چ کێشە کار دکەت\n✅ .بلۆر (Blur): ب شێوەیەکێ دروست کار دکەت\n✅ .پشکێن پارەی (Paid Features): هەمی پشکێن پارەی ب تەمامی یێن چست کرین (Unlocked)",
    icon: "https://i.postimg.cc/MTC22cZR/photo-2026-05-04-21-51-37.jpg",
    banner: "https://picsum.photos/seed/vstarpro/600/300",
    rating: 5.0,
    downloads: "50K+",
    author: "Yousif.duski",
    ipaLink: "https://shrinkme.click/yousif782",
    directLink: "https://url-shortener.me/LV5F",
    platform: 'ios'
  },
  {
    id: "video-star",
    name: "video Star",
    category: "Media",
    size: "158 MB",
    version: "v1.0",
    description: "Create amazing fan edits and music videos with Video Star. All premium effects and features are fully unlocked.",
    updateLog: "✨ تایبەتمەندی:\n\n✅ .کۆد: هەمی کۆد ب دروستی کار دکەن.\n✅ .ئیفێکتێ گلیچ (Glitch Effect): هەمی ئیفێکت ب تەمامی دهێنە نیشادان\n✅ .ترانسفۆرم (Transform): هەمی کۆد دهێنە خاندن\n✅ .ئیفێکتێ ئاگرى (Fire Effect): ب بێ چ کێشە کار دکەت\n✅ .بلۆر (Blur): ب شێوەیەکێ دروست کار دکەت\n✅ .پشکێن پارەی (Paid Features): هەمی پشکێن پارەی ب تەمامی یێن چست کرین (Unlocked)",
    icon: "https://i.postimg.cc/QdNQ3Xtk/photo-2026-05-03-20-35-20.jpg",
    banner: "https://picsum.photos/seed/videostar/600/300",
    rating: 4.9,
    downloads: "250K+",
    author: "Yousif.duski",
    ipaLink: "https://shrinkme.click/gp6Z7",
    directLink: "https://url-shortener.me/LTQY",
    platform: 'ios'
  },
  {
    id: "pool",
    name: "8 Ball Pool MOD",
    category: "Games",
    size: "110 MB",
    version: "v56.25.1",
    description: "The most professional 8 Ball Pool mod by RA KURD. Includes professional tools for better gameplay experience.",
    updateLog: "🎱 تایبەتمەندی:\n\n• Bug fixes: چاککرنا کێشەیان\n• Improved bypass: چارەسەرکرنا باندبوونا ئەکاونتی\n• Prediction lines: هێڵێن پێشبینیێ (ب دروستیا ١٠٠٪)\n• Auto Queue: کۆمکرنا خۆکار یا کۆینز ب شێوەیەکێ شێتانە\n• Auto Lucky Shot: لێدانا شانسی یا خۆکار\n• Auto Aim: نیشانەگرتنا خۆکار (مۆدێ زیرەک و هێرشبەر)\n• Fake Breakshot: لێدانا دەستپێکێ یا ساختە\n• Aim Guide: ڕێبەرا نیشانەگرتنێ\n• Adblock: نەهێلانا ڕیکلامان\n• Reset Guest: سفرکرنا ئەکاونتێ مێهوان\n• Load & Save guest: بارکرن و پاشکەفتکرنا ئەکاونتێ مێهوان\n• Styling options: گەلەک بژاردەیێن دیزاین و شێوازی",
    icon: "https://i.postimg.cc/bYSCq1kb/unnamed-(16).jpg",
    banner: "https://picsum.photos/seed/pool-banner/600/300",
    rating: 5.0,
    downloads: "250K+",
    author: "Yousif.duski",
    ipaLink: "https://shrinkme.click/LmSA79H9",
    directLink: "itms-services://?action=download-manifest&url=https://pub-b6abf7b6f3404bcfaacf050fc613059a.r2.dev/0027434b-a866-4621-815c-0850c1938158/manifest.plist",
    platform: 'ios'
  },
  {
    id: "pubg-skin",
    name: "PUBG MOBILE SKIN",
    category: "Games",
    size: "3.4 GB",
    version: "v3.1.0",
    description: "Experience PUBG Mobile with all skins unlocked and aim bot capabilities. A powerful modification for enthusiasts.",
    updateLog: "⚔️ تایبەتمەندی:\n✅ هەمی سکین | ✅ aim bot",
    warning: "⚠️ ئاگەداری: ئەم بەرپرس نینین ژ بەند بوونا ئەکاونتێ تە، بکارئینان ل سەر بەرپرسیارەتییا تە بخۆیە.",
    icon: "https://i.postimg.cc/HLHy2nDm/unnamed-(8).jpg",
    banner: "https://picsum.photos/seed/pubgskin/600/300",
    rating: 4.5,
    downloads: "150K+",
    author: "Yousif.duski",
    ipaLink: "https://mega.nz/file/FvYlVSZD#KJVyavH9SVUPtm6RnkUilYpcNjjIrEu9QxVGVItOXyg",
    platform: 'ios'
  },
  {
    id: "traffic",
    name: "Traffic Racer Pro MOD",
    category: "Games",
    size: "252.3 MB",
    version: "v2.1.2",
    description: "Modified version of Traffic Racer Pro with unlimited money and all cars unlocked.",
    updateLog: "🚗 تایبەتمەندی:\n✅ پارێ بێسنوور | ✅ هەمی ترومبێل د ڤکرینە",
    icon: "https://i.postimg.cc/g2sBR1tw/unnamed-(6).jpg",
    banner: "https://picsum.photos/seed/traffic-race/600/300",
    rating: 4.8,
    downloads: "120K+",
    author: "Yousif.duski",
    ipaLink: "https://shrinkme.click/yousif788",
    directLink: "https://loadly.io/yousifduski4",
    platform: 'ios'
  },
  {
    id: "rdr",
    name: "Red Dead Redemption",
    category: "Games",
    size: "2.69 GB",
    version: "v1.0.0",
    description: "Experience the epic Western adventure Red Dead Redemption on your mobile device for free.",
    updateLog: "⚔️ تایبەتمەندی:\n✅ رێدێد بەلاش (Free)",
    icon: "https://i.postimg.cc/8zYz1Xd5/unnamed-(5).jpg",
    banner: "https://picsum.photos/seed/rdr/600/300",
    rating: 4.9,
    downloads: "60K+",
    author: "Yousif.duski",
    ipaLink: "https://www.mediafire.com/file/20ofpamksbll1gv/Red+Dead+Redemption+Free.ipa/file",
    platform: 'ios'
  },
  {
    id: "coc",
    name: "Clash of Clans Mod",
    category: "Games",
    size: "410.2 MB",
    version: "v15.0.0",
    description: "Clash of Clans modified with unlimited resources and private server access.",
    updateLog: "⚔️ تایبەتمەندی:\n✅ پارە و ئەڵماس بێسنوور (Unlimited)\n✅ سێرڤەرێ تایبەت (Private Server)\n✅ هەمی سەرباز ڤکرینە",
    icon: "https://i.postimg.cc/QMV2gqVt/unnamed-(3).jpg",
    banner: "https://picsum.photos/seed/cocmod/600/300",
    rating: 4.8,
    downloads: "300K+",
    author: "Yousif.duski",
    ipaLink: "https://url-shortener.me/LGG4",
    directLink: "https://url-shortener.me/L3UJ",
    platform: 'ios'
  },
  {
    id: "dr-driving",
    name: "Dr. Driving Mod",
    category: "Games",
    size: "13.3 MB",
    version: "v1.70",
    description: "Dr. Driving with unlimited gold and all cars unlocked. Enjoy a completely ad-free experience.",
    updateLog: "🚗 تایبەتمەندیێن مۆدێ:\n✅ زێڕێ بێسنوور (Unlimited Gold)\n✅ هەمی ترومبێل د ڤکرینە\n✅ بێ ریکلام (No Ads)",
    icon: "https://i.postimg.cc/zXVLK4TH/unnamed.jpg",
    banner: "https://picsum.photos/seed/drdriving/600/300",
    rating: 4.7,
    downloads: "450K+",
    author: "Yousif.duski",
    ipaLink: "https://shrinkme.click/Mdc7",
    directLink: "itms-services://?action=download-manifest&url=https://applejr.net/download/99e29f02-c5f3-425b-bd96-44d39a003877.plist",
    platform: 'ios'
  },
  {
    id: "gta-sa",
    name: "GTA: SA - RA KURD",
    category: "Games",
    size: "2.5 GB",
    version: "Definitive",
    description: "GTA San Andreas Definitive Edition for iOS. Compatible with iOS 16 and fixed for iOS 18/19 crashes.",
    updateLog: "🎮 وەشانا Definitive:\n✅ بێ بەرامبەر (Free)\n✅ پشتەڤانیا iOS 16 و نویتر\n✅ چارەسەریا کراشێ ل iOS 26",
    icon: "https://i.postimg.cc/bdfjVVvq/unnamed-(3).jpg",
    banner: "https://picsum.photos/seed/gtasa/600/300",
    rating: 4.9,
    downloads: "200K+",
    author: "Yousif.duski",
    ipaLink: "https://mega.nz/file/RyxWmITI#fWLbue1FBU79KaOjAOonqZ6p66juSneaOCDhq9mglmU",
    platform: 'ios'
  },
  {
    id: "minecraft",
    name: "Minecraft",
    category: "Games",
    size: "832 MB",
    version: "v1.20.0",
    description: "Explore infinite worlds and build everything from the simplest of homes to the grandest of castles.",
    updateLog: "✨ تایبەتمەندی:\n\n✅ mincraft بەلاش (Free)",
    icon: "https://i.postimg.cc/sgqQqKJy/unnamed-(17).jpg",
    banner: "https://picsum.photos/seed/minecraft/600/300",
    rating: 4.9,
    downloads: "500K+",
    author: "Yousif.duski",
    ipaLink: "https://shrinkme.click/aaG6D",
    directLink: "itms-services://?action=download-manifest&url=https://bot.ipasign.cc/dl/202607250632247773329/ufJFUmvzSKGa.plist",
    platform: 'ios'
  },
  {
    id: "capcut-mod",
    name: "CapCut Mod",
    category: "Media",
    size: "140 MB",
    version: "Premium",
    description: "The most popular video editing app with all premium features unlocked, no watermark, and high-quality export.",
    updateLog: "✨ تایبەتمەندی:\n\n✅ هەمی ڕیکلام هاتینە لادان\n✅ پشتەڤانیا 1080 و بەرەڤ سەری دکەت\n✅ پشکەکا زۆرا تایبەتمەندییان هاتینە کاراکردن\n✅ لۆگۆیێ کێپ کەت هاتیە ژێبرن",
    icon: "https://i.postimg.cc/GmpzzRFV/unnamed-(20).jpg",
    banner: "https://picsum.photos/seed/capcut/600/300",
    rating: 4.9,
    downloads: "800K+",
    author: "Yousif.duski",
    ipaLink: "https://shrinkme.click/iBOSplv",
    directLink: "https://loadly.io/yousifduski7",
    platform: 'ios'
  },
  {
    id: "mytv-plus",
    name: "myTv+",
    category: "Media",
    size: "12.0 MB",
    version: "v1.0",
    description: "Watch your favorite TV channels and movies for free with the modified myTv+ application.",
    updateLog: "✨ تایبەتمەندی:\n\n✅ mytv بەلاش (Free)",
    icon: "https://i.postimg.cc/Xq1H6tCR/photo-2026-05-02-16-00-53.jpg",
    banner: "https://picsum.photos/seed/mytvplus/600/300",
    rating: 4.9,
    downloads: "120K+",
    author: "Yousif.duski",
    ipaLink: "https://shrinkme.click/ocDAE7",
    directLink: "itms-services://?action=download-manifest&url=https://bot.ipasign.cc/dl/202607250604018986f41/h3DTtH1lRdaF.plist",
    platform: 'ios'
  },
  {
    id: "mytv-plus-android",
    name: "myTv+",
    category: "Media",
    size: "12.0 MB",
    version: "v1.0",
    description: "Watch your favorite TV channels and movies for free with the modified myTv+ application for Android.",
    updateLog: "✨ تایبەتمەندی:\n\n✅ mytv بەلاش (Free)",
    icon: "https://i.postimg.cc/28fMrNM2/photo-2026-05-02-16-01-02.jpg",
    banner: "https://picsum.photos/seed/mytvplusandroid/600/300",
    rating: 4.9,
    downloads: "80K+",
    author: "Yousif.duski",
    ipaLink: "https://url-shortener.me/LSGP",
    directLink: "https://url-shortener.me/LSGP",
    platform: 'android'
  },
  {
    id: "youtube-mod",
    name: "YouTube Mod",
    category: "Media",
    size: "124 MB",
    version: "v19.0.0",
    description: "Enhanced YouTube app with ad-blocking, background playback, and easy sign-in.",
    updateLog: "🚀 تایبەتمەندی:\n✅ بێ ریکلام | ✅ کارکرن ل پشت پەردێ | ✅ Sign-in",
    icon: "https://i.postimg.cc/28dM8gP5/unnamed.jpg",
    banner: "https://picsum.photos/seed/ytmod/600/300",
    rating: 4.9,
    downloads: "1.2M+",
    author: "Yousif.duski",
    ipaLink: "https://shrinkme.click/Bjrjbnke",
    directLink: "itms-services://?action=download-manifest&url=https://pub-b6abf7b6f3404bcfaacf050fc613059a.r2.dev/bdcb0b1a-958d-4760-99c7-7dd7a6c7e0d7/manifest.plist",
    platform: 'ios'
  },
  {
    id: "pizza-ready",
    name: "Pizza Ready Mod",
    category: "Games",
    size: "148.23 MB",
    version: "v1.2.0",
    description: "Free in-app purchases for Pizza Ready. Simply click to buy and then cancel for success.",
    updateLog: "🛒 ستۆرا بێ بەرامبەر:\n١. کلیک ل سەر کڕینێ بکە | ٢. کلیک ل Cancel بکە.",
    icon: "https://i.postimg.cc/QHPPVXsq/unnamed.png",
    banner: "https://picsum.photos/seed/pizzaready/600/300",
    rating: 4.6,
    downloads: "95K+",
    author: "Yousif.duski",
    ipaLink: "https://shrinkme.click/s1DRN",
    directLink: "https://url-shortener.me/L3W6",
    platform: 'ios'
  },
  {
    id: "picsart-vip",
    name: "PicsArt VIP",
    category: "Media",
    size: "100.2 MB",
    version: "v22.0.0",
    description: "PicsArt with VIP features fully unlocked. Use all premium assets and effects without limits.",
    updateLog: "🎨 VIP ڤەکری:\nهەمی تشت د ڤکرینە و بێ چ کێشە کار دکەن.",
    icon: "https://i.postimg.cc/XYstLxt2/unnamed.jpg",
    banner: "https://picsum.photos/seed/picsartvip/600/300",
    rating: 4.8,
    downloads: "500K+",
    author: "Yousif.duski",
    ipaLink: "https://shrinkme.click/KGIi",
    directLink: "itms-services://?action=download-manifest&url=https://bot.ipasign.cc/dl/20260725061620809b74c/ktPBHoNhTiCE.plist",
    platform: 'ios'
  },
  {
    id: "rdr-android",
    name: "Red Dead Redemption",
    category: "Games",
    size: "2.7 GB",
    version: "v1.0.0",
    description: "Experience the epic Western adventure Red Dead Redemption on your mobile device for free.",
    updateLog: "⚔️ تایبەتمەندی:\n✅ رێدێد بەلاش (Free)",
    icon: "https://i.postimg.cc/rp6RCbgK/unnamed-(7).jpg",
    banner: "https://picsum.photos/seed/rdrandroid/600/300",
    rating: 4.9,
    downloads: "80K+",
    author: "Yousif.duski",
    directLink: "https://files.an1.co/red-dead-redemption-mods_1.58.63226194-an1.com.apk",
    platform: 'android'
  },
  {
    id: "picsart-android",
    name: "PicsArt premium",
    category: "Media",
    size: "79.48 MB",
    version: "v22.0.0",
    description: "PicsArt with Gold Premium Unlocked. Use all premium assets and effects without limits.",
    updateLog: "🌟 تایبەتمەندیێن مۆدێ:\n✅ Gold Premium Unlocked\n✅ هەمی فلتەر و ستیکەر ڤکرینە\n✅ بێ ڕیکلام (No Ads)",
    icon: "https://i.postimg.cc/rmP9LS9z/unnamed-(2).jpg",
    banner: "https://picsum.photos/seed/picsartpremium/600/300",
    rating: 4.8,
    downloads: "400K+",
    author: "Yousif.duski",
    directLink: "https://url-shortener.me/J8ZB",
    platform: 'android'
  },
  {
    id: "pool-android",
    name: "8 Ball Pool Mod",
    category: "Games",
    size: "78.8 MB",
    version: "v56.21.1",
    description: "The most professional 8 Ball Pool mod for Android. Includes professional tools for better gameplay experience.",
    updateLog: "🎱 تایبەتمەندیێن مۆدێ (v56.21.1):\n✅ هێلا درێژ (Long Line)\n✅ مینیۆیا مۆدێ (Mod Menu)\n✅ لێدانا بێسنوور (Mega Hit)",
    icon: "https://i.postimg.cc/kXGvh1P9/unnamed-(1).jpg",
    banner: "https://picsum.photos/seed/poolandroid/600/300",
    rating: 5.0,
    downloads: "200K+",
    author: "Yousif.duski",
    directLink: "https://url-shortener.me/J8ZT",
    platform: 'android'
  },
  {
    id: "tiktok-android",
    name: "TikTok Premium",
    category: "Media",
    size: "184 MB",
    version: "v44.5.5",
    description: "Enhanced TikTok app for Android with no watermark and unlocked features.",
    updateLog: "✨ تایبەتمەندیێن مۆدێ (v44.5.5):\n✅ بێ نیشان (No Watermark) | ✅ پلەگین (Plugin) ڤەکری",
    icon: "https://i.postimg.cc/GpKh8Rm2/unnamed-(2).jpg",
    banner: "https://picsum.photos/seed/tiktokpremium/600/300",
    rating: 4.9,
    downloads: "1.5M+",
    author: "Yousif.duski",
    directLink: "https://url-shortener.me/J90A",
    platform: 'android'
  },
  {
    id: "roblox-android",
    name: "Roblox MOD",
    category: "Games",
    size: "156 MB",
    version: "v2.600",
    description: "Roblox with a massive mod menu including fly, wallhack, and more.",
    updateLog: "🎮 مۆد مینیۆ (60 تشت):\n✅ مینیۆیا مەزن | ✅ فڕین (Fly) | ✅ دەربازبوون ژ دیواران",
    icon: "https://i.postimg.cc/wM52gywh/unnamed-(1).jpg",
    banner: "https://picsum.photos/seed/robloxmod/600/300",
    rating: 4.7,
    downloads: "900K+",
    author: "Yousif.duski",
    directLink: "https://url-shortener.me/J90T",
    platform: 'android'
  },
  {
    id: "traffic-android",
    name: "Traffic Racer Pro",
    category: "Games",
    size: "489.21 MB",
    version: "v2.1.2",
    description: "Unlimited money and all cars unlocked for Traffic Racer Pro on Android.",
    updateLog: "🤖 بێسنوور:\n✅ پارێ بێسنوور | ✅ هەمی ترومبێل د ڤکرینە",
    icon: "https://i.postimg.cc/kgKj6Tv7/unnamed.webp",
    banner: "https://picsum.photos/seed/trafficandroid/600/300",
    rating: 4.8,
    downloads: "150K+",
    author: "Yousif.duski",
    directLink: "https://url-shortener.me/J90X",
    platform: 'android'
  },
  {
    id: "minecraft-android",
    name: "Minecraft MOD",
    category: "Games",
    size: "883 MB",
    version: "v1.20",
    description: "Minecraft with mod menu, auto-hit, and god mode.",
    updateLog: "🔥 مۆد مینیۆ:\n✅ مینیۆیا مەزن | ✅ لێدانا ئۆتۆماتیکی | ✅ نامریت",
    icon: "https://i.postimg.cc/d3LV0kd3/Screenshot-2026-03-25-163801.png",
    banner: "https://picsum.photos/seed/minecraftmod/600/300",
    rating: 4.9,
    downloads: "2M+",
    author: "Yousif.duski",
    directLink: "https://url-shortener.me/J8TY",
    platform: 'android'
  }
];

// --- Translations ---
const TRANSLATIONS: Record<Language, Record<string, string>> = {
  ku_ba: {
    welcome: "بێخێرهاتی بۆ",
    featured: "بەرنامەیێن تایبەت",
    recent: "چالاکیا دوماهیێ",
    professionalTools: "ئامرازێن پرۆفیشناڵ",
    professionalDesc: "پرۆفیشناڵترین ستۆرا کوردی بۆ بەرنامەیێن هاککری و دەگمەن بۆ سیستەمێ iOS و Android.",
    getStarted: "دەستپێبکە",
    searchPlaceholder: "لێگەڕیان ل بەرنامان...",
    rating: "هەڵسەنگاندن",
    size: "قەبارە",
    version: "وەشان",
    description: "دەربارەی بەرنامەی",
    developerLogs: "گۆڕانکاریێن نوی",
    downloadIpa: "داگرتنا IPA",
    install: "داگرتنا ڕاستەوخۆ",
    customization: "تایبەتمەندکرن",
    appearance: "شێوازێ دیمەنی",
    brandSignature: "رەنگێ ستۆرێ",
    storeLocalization: "زمانێ ستۆرێ",
    officialFeed: "تۆڕێن جڤاکی",
    founder: "دامەزرێنەر و گەشەپێدەر",
    certActive: "باوەرنامە: چالاکە و پشتڕاستکرییە",
    howToTrust: "چەوانیا باوەرپێکرنێ",
    iosInstructions: "بۆ کارپێکرنا بەرنامەی: بچۆ ڕێکخستنێن تەلەفۆنێ -> گشتی -> مدیریت دستگاه -> باوەرپێکرن ب پڕۆفایلێ گەشەپێدەری.",
    activeDevices: "ئامێرێن کارا",
    revokeStatus: "پاراستن ژ بەندبوونێ",
    totalSigned: "بەرنامەیێن ساینکری",
    trending: "ترێندینگ",
    connecting: "پەیوەندیکردن ب سێرڤەری...",
    signing: "ساینکرنا بەرنامەی ب باوەرنامێ...",
    manifesting: "دروستکرنا فایلی داگرتنێ...",
    installSuccess: "پەیاما داگرتنێ هاتە نیشادان! ژ کەرەما خۆ سەیری شاشا سەرەکی یا موبایلا خۆ بکە.",
    copySuccess: "کۆد هاتە کۆپیکردن!",
    search: "لێگەڕیان",
    all: "هەمی",
    games: "یاری",
    media: "میدیا",
    safe: "سەلامەت",
    author: "گەشەپێدەر",
    howToInstall: "ڕێبەرا داگرتنێ",
    activeLabel: "چالاکە",
    securedLabel: "پاراستییە",
    developerName: "یوسف دۆسکی",
    clickCopy: "بۆ کۆپیکرنا کلیلا بەلاش ل سەر دابگرە",
    stepsTitle: "هەنگاوێن متمانەپێکرنێ ل سەر iOS",
    step1: "١. بچۆ ناڤ ڕێکخستنێن ئامێرێ خۆ (Settings)",
    step2: "٢. کلیک ل سەر بەشێ گشتی بکە (General)",
    step3: "٣. بچۆ ناڤ بەشێ (VPN & Device Management)",
    step4: "٤. پڕۆفایلێ گەشەپێدەری هەلبژێرە و پاشان کلیک ل سەر Trust بکە",
    countdownTitle: "پشکنینا ئەولەهیێ یا هژمارا پاشڤە",
    countdownLabel: "ڤەگوهاستن بۆ لینکێ داگرتنێ دگەل چرکەیێن ماین:",
    secondsRemaining: "چرکەیێن ماین",
    countdownSkip: "دەربازکرنا چاڤەڕێکرنێ",
    countdownOption10s: "١٠ چرکە (توندوتۆڵ)",
    countdownOption1m: "١ خۆلەک (پاراستنا بەرز)",
  },
  ku_so: {
    welcome: "بەخێربێیت بۆ",
    featured: "بەرنامە تایبەتەکان",
    recent: "چالاکی کۆتایی",
    professionalTools: "ئامرازە پرۆفیشناڵەکان",
    professionalDesc: "پرۆفیشناڵترین ستۆری کوردی بۆ بەرنامەی هاککراو و دەگمەن بۆ سیستەمی iOS و Android.",
    getStarted: "دەستپێبکە",
    searchPlaceholder: "گەڕان لە بەرنامەکان...",
    rating: "هەڵسەنگاندن",
    size: "قەبارە",
    version: "وەشان",
    description: "دەربارەی بەرنامە",
    developerLogs: "گۆڕانکارییەکانی نوێ",
    downloadIpa: "داگرتنی IPA",
    install: "داگرتنی ڕاستەوخۆ",
    customization: "تایبەتمەندکردن",
    appearance: "شێوازی مۆد",
    brandSignature: "ڕەنگی هێما",
    storeLocalization: "زمانی ستۆر",
    officialFeed: "تۆڕە کۆمەڵایەتییەکان",
    founder: "دامەزرێنەر و گەشەپێدەر",
    certActive: "بڕوانامە: چالاکە و باوەڕپێکراوە",
    howToTrust: "چۆنیەتی متمانەپێکردن",
    iosInstructions: "بۆ کارپێکردنی بەرنامەکە: بچۆ بۆ ڕێکخستنەکانی مۆبایل -> گشتی -> بەڕێوەبردنی ئامێر -> متمانەکردن بە گەشەپێدەر.",
    activeDevices: "ئامێرە چالاکەکان",
    revokeStatus: "پاراستن لە بەندبوون",
    totalSigned: "بەرنامە ساینکراوەکان",
    trending: "ترێند",
    connecting: "پەیوەندیکردن بە سێرڤەری سەرەکی...",
    signing: "ساینکردنی پاکێج بە متمانەی باڵا...",
    manifesting: "ئامادەکردنی فایلی دامەزراندن...",
    installSuccess: "پەیامی داگرتن پیشاندرا! تکایە سەیری شاشەی سەرەکی مۆبایلەکەت بکە.",
    copySuccess: "کۆد کۆپی کرا!",
    search: "گەڕان",
    all: "هەموو",
    games: "یارییەکان",
    media: "میدیاکان",
    safe: "سەلامەت",
    author: "نووسەر",
    howToInstall: "چۆنیەتی داگرتن",
    activeLabel: "چالاکە",
    securedLabel: "پارێزراوە",
    developerName: "یوسف دۆسکی",
    clickCopy: "بۆ کۆپیکردنی کلیلەکە کلیک لێرە بکە",
    stepsTitle: "هەنگاوەکانی متمانەپێکردن لە iOS",
    step1: "١. بچۆ بۆ ڕێکخستنەکانی مۆبایلەکەت (Settings)",
    step2: "٢. کلیک لەسەر بەشی گشتی بکە (General)",
    step3: "٣. بچۆ بۆ بەشی (VPN & Device Management)",
    step4: "٤. ناوی گەشەپێدەرەکە هەڵبژێرە و پاشان کلیک لەسەر Trust بکە",
    countdownTitle: "پشکنینی ئەمنییەتی ژمارەی پاشەکشێ",
    countdownLabel: "ڕەوانەکردن بۆ لیکی داگرتن لەگەڵ چرکەی ماوە:",
    secondsRemaining: "چرکەی ماوە",
    countdownSkip: "تێپەڕاندنی چاوەڕوانی",
    countdownOption10s: "١٠ چرکە (خێرا)",
    countdownOption1m: "١ خولەک (پاراستنی بەرز)",
  },
  en: {
    welcome: "Welcome to",
    featured: "Featured Apps",
    recent: "Recent Activity",
    professionalTools: "Professional Tools",
    professionalDesc: "The most professional Kurdish store for exclusive iOS assets and modified packages.",
    getStarted: "Get Started",
    searchPlaceholder: "Search apps...",
    rating: "Rating",
    size: "Size",
    version: "Version",
    description: "Description",
    developerLogs: "Developer Logs",
    downloadIpa: "Download IPA",
    install: "Direct Install",
    customization: "Customization",
    appearance: "Appearance Logic",
    brandSignature: "Brand Signature",
    storeLocalization: "Store Localization",
    officialFeed: "Official Feed",
    founder: "Founder & Developer",
    certActive: "Developer Certificate: ACTIVE & SECURED",
    howToTrust: "How to Install & Trust",
    iosInstructions: "To open this app: Go to Settings -> General -> VPN & Device Management -> Trust developer profile.",
    activeDevices: "Active Devices",
    revokeStatus: "Revoke Status",
    totalSigned: "Total Signed Apps",
    trending: "Trending",
    connecting: "Connecting to secure signing server...",
    signing: "Signing IPA packages with enterprise license...",
    manifesting: "Generating direct OTA install manifest...",
    installSuccess: "Installation prompted! Please check your home screen to see progress.",
    copySuccess: "Key copied to clipboard!",
    search: "Search",
    all: "All",
    games: "Games",
    media: "Media",
    safe: "SAFE",
    author: "Author",
    howToInstall: "Installation Guide",
    activeLabel: "Active",
    securedLabel: "Secured",
    developerName: "Yousif Duski",
    clickCopy: "Tap to copy the free trial key",
    stepsTitle: "How to Trust Enterprise Profile",
    step1: "1. Open your iOS Settings application",
    step2: "2. Scroll down and choose General",
    step3: "3. Navigate to VPN & Device Management",
    step4: "4. Select the developer profile and tap Trust",
    countdownTitle: "GATEWAY SECURITY COUNTDOWN",
    countdownLabel: "Redirecting to download link in seconds:",
    secondsRemaining: "Seconds Remaining",
    countdownSkip: "Skip Delay & Direct Install",
    countdownOption10s: "10 Seconds (Fast Connect)",
    countdownOption1m: "1 Minute (Ultra Secure)",
  },
  ar: {
    welcome: "مرحباً بك في",
    featured: "التطبيقات المميزة",
    recent: "النشاطات الأخيرة",
    professionalTools: "أدوات احترافية",
    professionalDesc: "المتجر الكردي الأكثر احترافية للتطبيقات المعدلة والحصرية لنظامي iOS و Android.",
    getStarted: "ابدأ الآن",
    searchPlaceholder: "البحث عن التطبيقات...",
    rating: "التقييم",
    size: "الحجم",
    version: "الإصدار",
    description: "الوصف",
    developerLogs: "سجل التحديثات",
    downloadIpa: "تحميل IPA",
    install: "تثبيت مباشر",
    customization: "التخصيص",
    appearance: "مظهر المتجر",
    brandSignature: "لون الهوية",
    storeLocalization: "لغة المتجر",
    officialFeed: "الحسابات الرسمية",
    founder: "المؤسس والمطور",
    certActive: "شهادة المطور: تعمل بنجاح وبأمان كامل",
    howToTrust: "كيفية توثيق الشهادة",
    iosInstructions: "لتشغيل التطبيق: اذهب إلى الإعدادات -> عام -> إدارة الأجهزة -> توثيق ملف تعريف المطور.",
    activeDevices: "الأجهزة النشطة",
    revokeStatus: "حالة الشهادة",
    totalSigned: "التطبيقات الموقعة",
    trending: "شائع",
    connecting: "جاري الاتصال بخادم التوقيع المباشر...",
    signing: "توقيع الحزمة بشهادة المطور الحالية...",
    manifesting: "جاري إعداد رابط التثبيت الفوري...",
    installSuccess: "تم بدء التثبيت! يرجى التحقق من الشاشة الرئيسية لجهازك.",
    copySuccess: "تم نسخ الكود بنجاح!",
    search: "بحث",
    all: "الكل",
    games: "الألعاب",
    media: "الوسائط",
    safe: "آمن",
    author: "المطور",
    howToInstall: "طريقة التثبيت",
    activeLabel: "نشط",
    securedLabel: "محمي",
    developerName: "يوسف دوسكي",
    clickCopy: "اضغط لنسخ مفتاح التجربة المجاني",
    stepsTitle: "خطوات توثيق الشهادة على iOS",
    step1: "١. افتح تطبيق الإعدادات في جهازك (Settings)",
    step2: "٢. اختر عام من القائمة (General)",
    step3: "٣. انتقل إلى إدارة ملفات التعريف والأجهزة (VPN & Device Management)",
    step4: "٤. اختر اسم المطور واضغط على زر التوثيق (Trust)",
    countdownTitle: "بوابة فحص الحماية والعد التنازلي",
    countdownLabel: "جاري التوجيه لرابط التحميل خلال ثوانٍ:",
    secondsRemaining: "ثواني متبقية",
    countdownSkip: "تخطي الانتظار والتثبيت المباشر",
    countdownOption10s: "10 ثوانٍ (اتصال سريع)",
    countdownOption1m: "دقيقة واحدة (حماية فائقة)",
  }
};

const translate = (key: string, lang: Language): string => {
  return TRANSLATIONS[lang]?.[key] || TRANSLATIONS["en"]?.[key] || key;
};

// --- Components ---

const ViewContainer = ({ children, staggered = true }: { children: React.ReactNode, staggered?: boolean }) => (
  <motion.div
    initial="hidden"
    animate="show"
    exit="exit"
    variants={{
      hidden: { opacity: 0 },
      show: {
        opacity: 1,
        transition: {
          staggerChildren: staggered ? 0.08 : 0,
          delayChildren: 0.1
        }
      },
      exit: {
        opacity: 0,
        scale: 1.02,
        transition: { duration: 0.2 }
      }
    }}
    className="flex-1 w-full max-w-lg mx-auto pb-32 pt-6 px-4 md:pt-14 font-sans relative z-10"
    style={{ 
      paddingTop: 'calc(env(safe-area-inset-top, 0px) + 24px)',
      paddingBottom: 'calc(env(safe-area-inset-bottom, 0px) + 110px)' 
    }}
  >
    {children}
  </motion.div>
);

const StaggerItem = ({ children, className = "", key }: { children: React.ReactNode, className?: string, key?: React.Key }) => (
  <motion.div
    key={key}
    variants={{
      hidden: { opacity: 0, y: 15, scale: 0.98 },
      show: { opacity: 1, y: 0, scale: 1, transition: { type: "spring", damping: 25, stiffness: 350 } }
    }}
    className={className}
  >
    {children}
  </motion.div>
);

const SectionHeader = ({ title, isDarkMode }: { title: string, isDarkMode: boolean }) => (
  <StaggerItem>
    <h2 className={`text-2xl font-black tracking-tight mb-5 px-1 font-display flex items-center justify-between ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
      <span>{title}</span>
      <span className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-ping opacity-60" />
    </h2>
  </StaggerItem>
);

const Card = ({ children, className = "", isDarkMode, style }: { children: React.ReactNode, className?: string, isDarkMode: boolean, style?: React.CSSProperties }) => (
  <div 
    style={style} 
    className={`rounded-[2.4rem] transition-all duration-500 overflow-hidden backdrop-blur-xl ${
      isDarkMode 
        ? 'bg-zinc-900/40 border-zinc-800/50 shadow-[0_12px_40px_rgba(0,0,0,0.35)]' 
        : 'bg-white/90 border-gray-100 shadow-[0_20px_40px_rgba(0,0,0,0.02)]'
    } border p-6 mb-5 ${className}`}
  >
    {children}
  </div>
);

const VerifiedBadge = ({ accentColor, lang }: { accentColor: string, lang: Language }) => (
  <div 
    className="flex items-center gap-1.5 px-3 py-0.5 rounded-full text-[8px] font-black tracking-[0.15em] uppercase shadow-sm border shrink-0"
    style={{ 
      backgroundColor: `${accentColor}0c`, 
      borderColor: `${accentColor}25`, 
      color: accentColor,
      textShadow: `0 0 10px ${accentColor}30`
    }}
  >
    <Check size={10} strokeWidth={4} />
    <span>{translate("safe", lang)}</span>
  </div>
);

// --- Custom Signer Constants & Translations ---
const FREE_CERTIFICATES = [
  {
    id: "cert_1",
    name: "Sunshine Insurance Group Co., Ltd",
    p12FileName: "Sunshine_Insurance_Group_Co_Ltd.p12",
    provFileName: "Sunshine_Insurance_Active_Shield.mobileprovision",
    password: "apple",
    status: "Active",
    statusText: {
      en: "Highly Stable",
      ku_ba: "کۆنتڕۆل و جێگیر",
      ku_so: "کۆنتڕۆڵ و جێگیر",
      ar: "مستقرة جداً"
    }
  },
  {
    id: "cert_2",
    name: "China United Network Communications Group",
    p12FileName: "China_United_Network.p12",
    provFileName: "China_United_Active_Shield.mobileprovision",
    password: "1",
    status: "Active",
    statusText: {
      en: "Stable",
      ku_ba: "جێگیرە",
      ku_so: "جێگیرە",
      ar: "مستقرة"
    }
  },
  {
    id: "cert_3",
    name: "Anhui Transport Consulting & Design Institute",
    p12FileName: "Anhui_Transport_Consulting.p12",
    provFileName: "Anhui_Transport_Active_Shield.mobileprovision",
    password: "123",
    status: "Active",
    statusText: {
      en: "New Certificate",
      ku_ba: "باوەرناما نوی",
      ku_so: "باوەرنامەی نوێ",
      ar: "شهادة جديدة"
    }
  }
];

const POPULAR_SIGN_APPS = [
  { id: "snap", name: "SNAP CHAT FLACON" },
  { id: "insta", name: "INSTGTAM++GOLD" },
  { id: "pubg", name: "PUNGMOBILEVIP" },
  { id: "troll", name: "TROLLSTOREINSTALL" },
  { id: "scarlet", name: "SCRELTINSTALL" }
];

const signerTranslations: Record<Language, Record<string, string>> = {
  en: {
    signerTitle: "RAKurd.store Web Signer",
    signerDesc: "Sign any IPA file using your purchased or custom developer certificate.",
    p12Label: "Upload Certificate (.p12)",
    provLabel: "Upload Provisioning Profile (.mobileprovision)",
    passwordLabel: "Certificate Password",
    appNameLabel: "Custom App Name",
    ipaLabel: "Upload IPA File (Optional)",
    selectApp: "Or select a popular app instead:",
    signBtn: "Sign IPA securely",
    signingUp: "Uploading payload to RAKurd secure sandbox...",
    signingParse: "Extracting bundle and parsing entitlements...",
    signingInject: "Injecting RAKurd.store anti-revoke bypass framework...",
    signingExec: "Cryptographically signing binaries...",
    signingPack: "Generating secure OTA manifest mapping...",
    successTitle: "Custom Sign Complete!",
    successDesc: "Your application has been successfully compiled and cryptographically signed under the RAKurd.store secure gateway.",
    dlIpa: "Download Signed IPA",
    directInstall: "Instant Direct Install",
    securedNotice: "Secure Link Shield: Copy protection active. Direct installation enabled.",
    fillDemo: "Fill Test Credentials",
  },
  ku_ba: {
    signerTitle: "ساینکرنا تایبەت RAKurd",
    signerDesc: "فایلی IPA ساین بکە ب باوەرناما خۆ یا کڕین یان یا بەلاش.",
    p12Label: "بارکرنا باوەرنامێ (.p12)",
    provLabel: "بارکرنا پڕۆفایلی (.mobileprovision)",
    passwordLabel: "پاسوۆردێ باوەرنامێ",
    appNameLabel: "ناڤێ بەرنامەی یێ خواستی",
    ipaLabel: "بارکرنا فایلی IPA (ئارەزوومەندانە)",
    selectApp: "یان بەرنامەکێ نیاسراو ل خوارێ هەلبژێرە:",
    signBtn: "ساینکرنا فایلی ب شێوەیەکێ پاراستی",
    signingUp: "بارکرنا فایلی بۆ سێرڤەرێن پاراستی یێن RAKurd...",
    signingParse: "شیکارکرنا فایلان و دەرئینانا داتایان...",
    signingInject: "زێدەکرنا سیستەمێ پاراستنا RAKurd دژی بەندبوونێ...",
    signingExec: "واژۆکرنا (ساینکرنا) بەرنامەی ب باوەرناما فەرمی...",
    signingPack: "دروستکرنا لینکێ داگرتنێ یێ تایبەت...",
    successTitle: "ساینکرن ب سەرکەفتى ئەنجامدرا!",
    successDesc: "بەرنامێ تە ب سەرکەفتن هاتە ساینکرن ل ژێر سێرڤەرێن ڕاستەوخۆ یێن RAKurd.store.",
    dlIpa: "داگرتنا فایلی IPA یێ ساینکری",
    directInstall: "دامەزراندنا ڕاستەوخۆ",
    securedNotice: "پاراستنا لینکێ RAKurd: کۆپیکردنا لینکێ ڕاستەوخۆ هاتیە ڕاگرتن بۆ ئەولەهیێ.",
    fillDemo: "تۆمارکرنا داتایێن تاقیکاریێ",
  },
  ku_so: {
    signerTitle: "ساینکردنی تایبەتی RAKurd",
    signerDesc: "فایلی IPA ساین بکە بە باوەرنامەی کڕدراو یان خۆڕایی خۆت.",
    p12Label: "بارکردنی باوەرنامە (.p12)",
    provLabel: "بارکردنی پڕۆفایل (.mobileprovision)",
    passwordLabel: "پاسوۆردی باوەرنامە",
    appNameLabel: "ناوی بەرنامەی دڵخواز",
    ipaLabel: "بارکردنی فایلی IPA (ئارەزوومەندانە)",
    selectApp: "یان لە خوارەوە بەرنامەیەکی ناسراو هەڵبژێرە:",
    signBtn: "ساینکردنی فایل بە پارێزراوی",
    signingUp: "بارکردنی فایل بۆ سێرڤەرە پارێزراوەکانی RAKurd...",
    signingParse: "شیکارکردنی فایلەکان و دەرکردنی زانیارییەکان...",
    signingInject: "زیادکردنی سیستەمی پاراستنی RAKurd دژی بەندبوون...",
    signingExec: "واژۆکردنی (ساینکردنی) بەرنامە بە باوەرنامەی فەرمی...",
    signingPack: "دروستکردنی لینکی داگرتنی تایبەت...",
    successTitle: "ساینکردن بە سەرکەوتوویی ئەنجامدرا!",
    successDesc: "بەرنامەکەت بە سەرکەوتوویی ساینکرا لەژێر سێرڤەرە ڕاستەوخۆکانی RAKurd.store.",
    dlIpa: "داگرتنی فایلی IPA ی ساینکراو",
    directInstall: "دامەزراندنی ڕاستەوخۆ",
    securedNotice: "پاراستنی لینکی RAKurd: کۆپیکردنی لینکی ڕاستەوخۆ ناچالاک کراوە بۆ ئەمنییەت.",
    fillDemo: "تۆمارکردنی زانیاری تاقیکاری",
  },
  ar: {
    signerTitle: "أداة توقيع RAKurd.store",
    signerDesc: "وقع أي ملف IPA باستخدام شهادتك الخاصة المدفوعة أو المجانية.",
    p12Label: "رفع ملف الشهادة (.p12)",
    provLabel: "رفع ملف الوصف (.mobileprovision)",
    passwordLabel: "كلمة مرور الشهادة",
    appNameLabel: "اسم التطبيق المخصص",
    ipaLabel: "رفع ملف الـ IPA (اختياري)",
    selectApp: "أو اختر تطبيقاً شائعاً من القائمة:",
    signBtn: "بدء التوقيع الآمن والتشييد",
    signingUp: "جاري رفع الملفات إلى بيئة توقيع RAKurd الآمنة...",
    signingParse: "جاري فك الحزمة وفحص صلاحيات التطبيق...",
    signingInject: "جاري حقن حزمة حماية RAKurd ضد التعطيل...",
    signingExec: "جاري تشفير وتوقيع التطبيق بالشهادة الرقمية...",
    signingPack: "جاري بناء روابط التثبيت والـ OTA manifest...",
    successTitle: "تم التوقيع بنجاح!",
    successDesc: "تم توقيع وتشفير تطبيقك الخاص بنجاح عبر خوادم بوابة RAKurd.store الآمنة.",
    dlIpa: "تحميل ملف IPA الموقع",
    directInstall: "تثبيت مباشر فوري",
    securedNotice: "درع حماية الروابط نشط: تم حظر النسخ المباشر لحفظ أمان الشهادة.",
    fillDemo: "تعبئة شهادة تجريبية"
  }
};

// --- Sub-views ---

const HomeView = ({ isDarkMode, accentColor, onSelectApp, lang, onSignerToggle }: { isDarkMode: boolean, accentColor: string, onSelectApp: (app: AppItem) => void, lang: Language, key?: React.Key, onSignerToggle?: (isOpen: boolean) => void }) => {
  const featuredApps = APPS.slice(0, 4);
  const recentApps = APPS.slice(4, 8);

  const isRtl = lang !== "en";

  const [selectedCert, setSelectedCert] = useState<"vip" | "free" | null>(null);
  const [isCertSigning, setIsCertSigning] = useState(false);
  const [certSignProgress, setCertSignProgress] = useState(0);

  // --- Custom Web Signer State & Logic ---
  const [selectedFreeCertId, setSelectedFreeCertId] = useState<string>("cert_1");
  const [copiedPasswordId, setCopiedPasswordId] = useState<string>("");
  const [certTab, setCertTab] = useState<"info" | "signer">("info");
  const [customP12, setCustomP12] = useState<File | null>(null);
  const [customP12Name, setCustomP12Name] = useState<string>("");
  const [customProv, setCustomProv] = useState<File | null>(null);
  const [customProvName, setCustomProvName] = useState<string>("");
  const [customIpa, setCustomIpa] = useState<File | null>(null);
  const [customIpaName, setCustomIpaName] = useState<string>("");
  const [customPassword, setCustomPassword] = useState("");
  const [customAppName, setCustomAppName] = useState("");
  const [selectedPopularApp, setSelectedPopularApp] = useState("");
  
  const [isCustomSigning, setIsCustomSigning] = useState(false);
  const [customSignProgress, setCustomSignProgress] = useState(0);
  const [customSignState, setCustomSignState] = useState<"idle" | "uploading" | "signing" | "packaging" | "ready">("idle");
  const [showIosInstallSim, setShowIosInstallSim] = useState(false);
  const [signerErrors, setSignerErrors] = useState<{
    p12?: boolean;
    prov?: boolean;
    password?: boolean;
    passwordMsg?: string;
  }>({});

  const isSignerReady = !!customP12Name && !!customProvName && (customPassword === "1" || customPassword === "rakurd.store");

  const handleFillDemoSigner = () => {
    setCustomP12Name("rakurd_distribution_enterprise.p12");
    setCustomProvName("rakurd_distribution_profile.mobileprovision");
    setCustomIpaName("TrollStore++_v2.0.8_RAKurd.ipa");
    setCustomPassword("rakurd.store");
    setCustomAppName("TrollStore++ RAKurd Edition");
    setSignerErrors({});
  };

  // Real-time custom signer field validator
  useEffect(() => {
    if (customP12Name && signerErrors.p12) {
      setSignerErrors(prev => ({ ...prev, p12: false }));
    }
    if (customProvName && signerErrors.prov) {
      setSignerErrors(prev => ({ ...prev, prov: false }));
    }
    
    if (customPassword) {
      if (customPassword !== "1" && customPassword !== "rakurd.store") {
        setSignerErrors(prev => ({
          ...prev,
          password: true,
          passwordMsg: 
            lang === "ku_ba" ? "پاسوۆردێ باوەرنامێ خەلەتە! ژ کەرەما خۆ دیسان تاقی بکە." :
            lang === "ku_so" ? "پاسوۆردی باوەرنامەکە هەڵەیە! تکایە دووبارە تاقی بکەرەوە." :
            lang === "ar" ? "كلمة مرور الشهادة غير صحيحة! يرجى المحاولة مرة أخرى." :
            "Incorrect certificate password! Please try again."
        }));
      } else {
        setSignerErrors(prev => ({ ...prev, password: false, passwordMsg: "" }));
      }
    } else {
      if (signerErrors.password) {
        setSignerErrors(prev => ({ ...prev, password: false, passwordMsg: "" }));
      }
    }
  }, [customP12Name, customProvName, customPassword, lang]);

  useEffect(() => {
    if (onSignerToggle) {
      onSignerToggle(selectedCert !== null);
    }
  }, [selectedCert, onSignerToggle]);

  useEffect(() => {
    let interval: any;
    if (isCertSigning) {
      setCertSignProgress(5);
      interval = setInterval(() => {
        setCertSignProgress(prev => {
          if (prev >= 100) {
            clearInterval(interval);
            setTimeout(() => {
              setIsCertSigning(false);
              window.location.href = "itms-services://?action=download-manifest&url=https://pub-b6abf7b6f3404bcfaacf050fc613059a.r2.dev/c6a3c90d-685b-4add-a8b0-d462eabce798/manifest.plist";
            }, 1000);
            return 100;
          }
          return prev + 15;
        });
      }, 300);
    } else {
      setCertSignProgress(0);
    }
    return () => clearInterval(interval);
  }, [isCertSigning]);

  useEffect(() => {
    let interval: any;
    if (isCustomSigning) {
      setCustomSignProgress(5);
      setCustomSignState("uploading");
      interval = setInterval(() => {
        setCustomSignProgress(prev => {
          const next = prev + 25;
          if (next >= 100) {
            clearInterval(interval);
            setCustomSignState("ready");
            return 100;
          }
          if (next > 75) {
            setCustomSignState("packaging");
          } else if (next > 25) {
            setCustomSignState("signing");
          }
          return next;
        });
      }, 100);
    } else {
      setCustomSignProgress(0);
    }
    return () => clearInterval(interval);
  }, [isCustomSigning]);

  const handleResetSigner = () => {
    setCustomP12(null);
    setCustomP12Name("");
    setCustomProv(null);
    setCustomProvName("");
    setCustomIpa(null);
    setCustomIpaName("");
    setCustomPassword("");
    setCustomAppName("");
    setSelectedPopularApp("");
    setIsCustomSigning(false);
    setCustomSignProgress(0);
    setCustomSignState("idle");
    setShowIosInstallSim(false);
    setSignerErrors({});
  };

  const getCertTitle = () => {
    switch(lang) {
      case "ku_ba": return "باوەرنامە (Certificates)";
      case "ku_so": return "باوەرنامە (Certificates)";
      case "ar": return "قسم الشهادات (Certificates)";
      default: return "Developer Certificates";
    }
  };

  return (
    <ViewContainer>
      {/* Top Brand Block */}
      <StaggerItem className="flex justify-between items-center mb-8 px-1">
        <div className="flex items-center gap-4">
          <div className="relative group cursor-pointer">
            <div 
              className="absolute inset-0 blur-md rounded-[1.6rem] opacity-70 transition-opacity group-hover:opacity-100" 
              style={{ backgroundColor: accentColor }}
            />
            <div 
              className="w-16 h-16 rounded-[1.6rem] overflow-hidden shadow-2xl relative z-10 transition-transform duration-500 group-hover:scale-105 group-hover:rotate-3" 
              style={{ border: `2.5px solid ${accentColor}` }}
            >
              <img src={LOGO_URL} alt="RA KURD Logo" className="w-full h-full object-cover" />
            </div>
            <span className="absolute -bottom-1 -right-1 bg-emerald-500 w-4 h-4 rounded-full border-2 border-zinc-950 flex items-center justify-center z-20">
              <span className="w-1.5 h-1.5 bg-white rounded-full animate-ping" />
            </span>
          </div>
          <div>
            <p className={`text-[9px] font-black uppercase tracking-[0.35em] mb-0.5 ${isDarkMode ? 'text-zinc-500' : 'text-gray-400'}`}>{translate("welcome", lang)}</p>
            <h1 className="text-2xl font-black tracking-tighter font-display leading-none">
              <span className="bg-clip-text text-transparent bg-gradient-to-r" style={{ backgroundImage: `linear-gradient(135deg, ${isDarkMode ? '#ffffff' : '#111827'} 40%, ${accentColor} 100%)` }}>
                RA KURD STORE
              </span>
            </h1>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <a
            href="https://t.me/RAkIRD1" 
            target="_blank" 
            rel="noopener noreferrer"
            className={`w-11 h-11 rounded-2xl flex items-center justify-center transition-all shadow-md active:scale-90 ${isDarkMode ? 'bg-zinc-900/60 border border-zinc-800/40 text-blue-400 hover:text-blue-300' : 'bg-white text-blue-500 border border-gray-100 hover:bg-gray-50'}`}
          >
            <Send size={18} strokeWidth={2.5} />
          </a>
          <a
            href="https://www.instagram.com/ra_kurd.store?igsh=MWxiZTVxdG55MnNwNw%3D%3D&utm_source=qr" 
            target="_blank" 
            rel="noopener noreferrer"
            className={`w-11 h-11 rounded-2xl flex items-center justify-center transition-all shadow-md active:scale-90 ${isDarkMode ? 'bg-zinc-900/60 border border-zinc-800/40 text-pink-500 hover:text-pink-400' : 'bg-white text-pink-600 border border-gray-100 hover:bg-gray-50'}`}
          >
            <Instagram size={18} strokeWidth={2.5} />
          </a>
        </div>
      </StaggerItem>



      {/* Horizontal Carousel (Featured) */}
      <div className="mb-10">
        <SectionHeader title={translate("featured", lang)} isDarkMode={isDarkMode} />
        <div className="flex gap-5 overflow-x-auto pb-4 scrollbar-none px-1">
          {featuredApps.map(app => (
            <motion.div 
              key={app.id}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => onSelectApp(app)}
              className={`min-w-[290px] h-48 rounded-[2.6rem] relative overflow-hidden cursor-pointer shadow-xl group border transition-all ${
                isDarkMode ? 'border-zinc-800/40 bg-zinc-950' : 'border-gray-100 bg-gray-100'
              }`}
            >
              <img 
                src={app.icon} 
                className="absolute inset-0 w-full h-full object-cover opacity-20 scale-105 group-hover:scale-115 transition-transform duration-1000 blur-[3px]" 
                referrerPolicy="no-referrer" 
              />
              <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-zinc-950/60 to-transparent" />
              <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-white/10 to-transparent transform -translate-x-full group-hover:translate-x-full transition-transform duration-1000" />

              <div className="absolute top-6 left-6 right-6 flex justify-between items-center z-10">
                 <div className="px-3.5 py-1.5 rounded-2xl bg-white/10 backdrop-blur-md border border-white/10 text-[8px] font-black text-white uppercase tracking-[0.25em]">
                   {translate("trending", lang)}
                 </div>
                 <div className="w-8 h-8 rounded-full bg-yellow-400/10 flex items-center justify-center border border-yellow-400/20">
                   <Zap size={16} className="text-yellow-400 fill-current animate-pulse" />
                 </div>
              </div>

              <div className="absolute bottom-6 left-6 right-6 z-10">
                <div className="flex items-center gap-4">
                  <div className="relative shrink-0">
                    <img src={app.icon} className="w-16 h-16 rounded-[1.4rem] border border-white/20 shadow-lg object-cover relative z-10" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5 mb-1.5">
                      <span className="relative flex h-2 w-2">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75" />
                        <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500" />
                      </span>
                      <p className="text-white/80 text-[8px] font-black uppercase tracking-widest">{app.category}</p>
                    </div>
                    <h4 className="text-white font-black text-xl tracking-tight leading-tight italic font-display truncate">
                      {app.name}
                    </h4>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Quick Promo Block */}
      <StaggerItem>
        <Card isDarkMode={isDarkMode} className="border-none text-white overflow-hidden relative p-8 mb-8 shadow-xl group cursor-pointer" style={{ backgroundColor: accentColor }}>
          {/* Custom background shimmer and floating highlight */}
          <div className="absolute inset-0 bg-gradient-to-tr from-black/15 via-transparent to-white/10 opacity-60 pointer-events-none" />
          <div className="absolute top-[-30%] right-[-10%] w-[180px] h-[180px] rounded-full blur-[40px] bg-white/20 group-hover:scale-110 transition-transform duration-700" />
          
          <div className="relative z-10">
            <h3 className="font-black text-2xl mb-1.5 font-display italic tracking-tight">{translate("professionalTools", lang)}</h3>
            <p className="text-white/90 text-xs mb-6 leading-relaxed font-semibold max-w-[85%] text-balance">{translate("professionalDesc", lang)}</p>
            <a 
              href="https://t.me/RAkIRD1" 
              target="_blank" 
              rel="noopener noreferrer"
              className="inline-block bg-white text-gray-900 px-6 py-3 rounded-2xl text-[9px] font-black uppercase tracking-[0.15em] transition-all active:scale-95 shadow-md hover:bg-gray-50 hover:scale-[1.02]"
            >
              {translate("getStarted", lang)}
            </a>
          </div>
          <Zap className="absolute -right-8 -bottom-8 w-44 h-44 text-white opacity-10 rotate-12 group-hover:rotate-6 transition-transform duration-500" />
        </Card>
      </StaggerItem>

      {/* Recent Activity Feed */}
      <SectionHeader title={translate("recent", lang)} isDarkMode={isDarkMode} />
      <div className="space-y-3.5">
        {recentApps.map((app) => (
          <StaggerItem key={app.id}>
            <Card 
              isDarkMode={isDarkMode} 
              className={`hover:translate-x-1 hover:border-zinc-700/50 transition-all cursor-pointer p-4 group ${
                isDarkMode 
                  ? 'bg-gradient-to-r from-zinc-900/40 via-zinc-900/20 to-zinc-950/60 border-zinc-800/60 shadow-lg' 
                  : 'bg-white border-gray-100 shadow-sm'
              }`}
            >
              <div onClick={() => onSelectApp(app)} className="flex items-center justify-between w-full gap-4">
                <div className="flex items-center gap-4 flex-1 min-w-0">
                  <div className={`w-14 h-14 rounded-[1.3rem] overflow-hidden shadow-md border ${isDarkMode ? 'border-zinc-800' : 'border-gray-50'} shrink-0 transition-transform duration-300 group-hover:scale-105 group-hover:rotate-1`}>
                    <img src={app.icon} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className={`font-black text-[15px] mb-1 leading-tight tracking-tight truncate transition-colors ${
                      isDarkMode ? 'text-zinc-100 group-hover:text-white' : 'text-gray-900 group-hover:text-black'
                    }`}>{app.name}</p>
                    <div className="flex items-center gap-2">
                      <VerifiedBadge accentColor={accentColor} lang={lang} />
                      <span className="w-1 h-1 rounded-full bg-zinc-300 dark:bg-zinc-800" />
                      <p className="text-[9px] font-black tracking-wider uppercase opacity-45">{app.category}</p>
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center gap-3 shrink-0">
                  <div className="text-right hidden sm:block">
                    <p className="text-[10px] font-black tracking-tight leading-none italic">{app.size}</p>
                    <p className="text-[8px] font-black tracking-widest opacity-40 uppercase mt-0.5">{translate("size", lang)}</p>
                  </div>
                  <div className={`w-9 h-9 rounded-full flex items-center justify-center transition-all ${
                    isDarkMode ? 'bg-zinc-900/80 text-zinc-400 border border-zinc-800 group-hover:border-zinc-700' : 'bg-gray-50 text-gray-400 border border-gray-100'
                  } group-hover:scale-105`} style={{ color: isDarkMode ? accentColor : undefined }}>
                    <ChevronRight size={16} className={`transition-transform group-hover:translate-x-0.5 ${isRtl ? "rotate-180 group-hover:-translate-x-0.5" : ""}`} />
                  </div>
                </div>
              </div>
            </Card>
          </StaggerItem>
        ))}
      </div>

      {/* Certificates Modal Overlay */}
      <AnimatePresence>
        {selectedCert && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[110] flex items-center justify-center p-4 backdrop-blur-md bg-black/60"
            dir={isRtl ? "rtl" : "ltr"}
          >
            <motion.div 
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              className={`w-full ${
                selectedCert === "free" && certTab === "signer" ? "max-w-lg" : "max-w-md"
              } rounded-[2.5rem] border p-6 relative overflow-hidden shadow-2xl transition-all duration-300 ${
                isDarkMode 
                  ? (signerErrors.p12 || signerErrors.prov || signerErrors.password)
                    ? 'bg-gradient-to-b from-zinc-950 via-red-950/40 to-black border-red-500/40 shadow-[0_0_50px_rgba(239,68,68,0.18)] text-white'
                    : selectedCert === "vip"
                    ? 'bg-gradient-to-b from-zinc-950 via-amber-950/30 to-black border-amber-500/20 shadow-[0_0_50px_rgba(245,158,11,0.18)] text-white'
                    : 'bg-gradient-to-b from-zinc-950 via-emerald-950/30 to-black border-emerald-500/20 shadow-[0_0_50px_rgba(16,185,129,0.18)] text-white'
                  : 'bg-white border-gray-100 text-gray-900'
              }`}
            >
              {/* Colored ambient glow backdrops inside the modal */}
              {isDarkMode && (
                <div className="absolute inset-0 pointer-events-none overflow-hidden rounded-[2.5rem] z-0">
                  <div className={`absolute -top-24 -left-24 w-48 h-48 rounded-full blur-[80px] opacity-25 transition-all duration-500 ${
                    (signerErrors.p12 || signerErrors.prov || signerErrors.password)
                      ? "bg-red-500"
                      : selectedCert === "vip" 
                      ? "bg-amber-500" 
                      : "bg-emerald-500"
                  }`} />
                  <div className={`absolute -bottom-24 -right-24 w-48 h-48 rounded-full blur-[80px] opacity-20 transition-all duration-500 ${
                    (signerErrors.p12 || signerErrors.prov || signerErrors.password)
                      ? "bg-red-600"
                      : selectedCert === "vip" 
                      ? "bg-amber-600" 
                      : "bg-emerald-600"
                  }`} />
                </div>
              )}
              {/* Close Button */}
              <button 
                onClick={() => {
                  setSelectedCert(null);
                  setIsCertSigning(false);
                  handleResetSigner();
                  setCertTab("info");
                }}
                className={`absolute top-5 right-5 w-9 h-9 rounded-xl flex items-center justify-center border transition-all z-[20] ${
                  isDarkMode 
                    ? 'bg-zinc-900/60 border-zinc-800 text-zinc-400 hover:text-white' 
                    : 'bg-gray-50 border-gray-200 text-gray-500 hover:text-black'
                }`}
              >
                <X size={16} strokeWidth={3} />
              </button>

              {/* Header Title Block */}
              <div className="flex flex-col items-center text-center mt-2 mb-4">
                <div className={`w-14 h-14 rounded-2xl flex items-center justify-center mb-3 relative ${
                  selectedCert === "vip" 
                    ? 'bg-amber-500/15 text-amber-400' 
                    : 'bg-emerald-500/15 text-emerald-400'
                }`}>
                  {selectedCert === "vip" ? <Star size={26} className="fill-current animate-pulse" /> : <ShieldCheck size={26} className="animate-pulse" />}
                </div>
                
                <h3 className={`text-xl font-black italic tracking-tight font-display ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                  {selectedCert === "vip" 
                    ? (lang === "ku_ba" ? "باوەرناما VIP" : lang === "ku_so" ? "باوەرنامەی VIP" : lang === "ar" ? "شهادة المطور الـ VIP" : "VIP Developer Certificate")
                    : (lang === "ku_ba" ? "باوەرناما بەلاش" : lang === "ku_so" ? "باوەرنامەی گشتی بەلاش" : lang === "ar" ? "بوابة الشهادة المجانية" : "Free Certificate Gateway")
                  }
                </h3>
                
                <span className={`text-[8.5px] font-black uppercase tracking-widest px-3 py-1 rounded-full mt-2 inline-block ${
                  selectedCert === "vip" 
                    ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20' 
                    : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                }`}>
                  {selectedCert === "vip" ? "PREMIUM ANTIGRAVITY SHIELD" : "RAKURD.STORE SECURE NODE"}
                </span>
              </div>

              {/* Modal Tabs Selector (Only for Free Certificate Mode) */}
              {selectedCert === "free" && !isCustomSigning && customSignState !== "ready" && (
                <div className="flex border-b border-zinc-800/10 dark:border-zinc-800/40 mb-6 mt-2 gap-2">
                  <button 
                    onClick={() => setCertTab("info")}
                    className={`pb-3 text-[10px] font-black uppercase tracking-wider transition-all relative flex-1 ${
                      certTab === "info" 
                        ? 'text-emerald-500' 
                        : 'text-zinc-400 hover:text-zinc-100'
                    }`}
                  >
                    {lang === "ku_ba" ? "باوەرناما گشتی" : lang === "ku_so" ? "باوەرنامەی گشتی" : lang === "ar" ? "الشهادة العامة" : "Public Profile"}
                    {certTab === "info" && (
                      <motion.div layoutId="certTabLine" className="absolute bottom-0 left-0 right-0 h-[2px] bg-emerald-500" />
                    )}
                  </button>
                  <button 
                    onClick={() => setCertTab("signer")}
                    className={`pb-3 text-[10px] font-black uppercase tracking-wider transition-all relative flex-1 ${
                      certTab === "signer" 
                        ? 'text-emerald-500' 
                        : 'text-zinc-400 hover:text-zinc-100'
                    }`}
                  >
                    {lang === "ku_ba" ? "ساینکرنا تایبەت (Signer)" : lang === "ku_so" ? "ساینکردنی تایبەت (Signer)" : lang === "ar" ? "توقيع خاص (Signer)" : "RAKurd Custom Signer"}
                    {certTab === "signer" && (
                      <motion.div layoutId="certTabLine" className="absolute bottom-0 left-0 right-0 h-[2px] bg-emerald-500" />
                    )}
                  </button>
                </div>
              )}

              {/* TAB CONTENT BLOCK */}
              <div className="overflow-y-auto max-h-[60vh] pr-1 pl-1 scrollbar-thin">
                {selectedCert === "vip" ? (
                  /* VIP Info Screen */
                  <div className="space-y-4 mb-6">
                    <div className="flex items-start gap-3">
                      <div className="w-5 h-5 rounded-lg bg-amber-500/10 flex items-center justify-center text-amber-400 shrink-0 mt-0.5"><Check size={12} strokeWidth={4} /></div>
                      <div>
                        <h4 className="text-xs font-black uppercase tracking-wide opacity-80">{lang === "ku_ba" ? "٣٦٥ ڕۆژ گرنتی ب تەمامی" : lang === "ku_so" ? "٣٦٥ ڕۆژ گەرەنتی تەواو" : lang === "ar" ? "ضمان كامل لمدة ٣٦٥ يوم" : "365 Days Guaranteed"}</h4>
                        <p className="text-[10px] opacity-45 leading-relaxed">{lang === "ku_ba" ? "باوەرنامە دێ بۆ سالەکێ کار کەت بێ بەندبوون" : lang === "ku_so" ? "باوەرنامە کار دەکات بۆ ساڵێک بەبێ بەندکردن" : lang === "ar" ? "تعمل الشهادة لمدة عام كامل دون توقف" : "Certificate works for 1 full year without revokes"}</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <div className="w-5 h-5 rounded-lg bg-amber-500/10 flex items-center justify-center text-amber-400 shrink-0 mt-0.5"><Check size={12} strokeWidth={4} /></div>
                      <div>
                        <h4 className="text-xs font-black uppercase tracking-wide opacity-80">{lang === "ku_ba" ? "سێرڤەرێ ساینکرنێ یێ تایبەت" : lang === "ku_so" ? "سێرڤەری ساینکردنی تایبەت" : lang === "ar" ? "خادم توقيع خاص ومحمي" : "Private Signing Server"}</h4>
                        <p className="text-[10px] opacity-45 leading-relaxed">{lang === "ku_ba" ? "تایبەت ل سەر ئامێرێ تە دهێتە تۆمارکرن" : lang === "ku_so" ? "تایبەت لەسەر ئامێری تۆ تۆمار دەکرێت" : lang === "ar" ? "يتم تسجيل الشهادة خصيصاً لجهازك" : "Registered uniquely on your device UDID"}</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <div className="w-5 h-5 rounded-lg bg-amber-500/10 flex items-center justify-center text-amber-400 shrink-0 mt-0.5"><Check size={12} strokeWidth={4} /></div>
                      <div>
                        <h4 className="text-xs font-black uppercase tracking-wide opacity-80">{lang === "ku_ba" ? "پشتەڤانیا هەمی بەرنامان" : lang === "ku_so" ? "پشتیوانی گشت بەرنامەکان" : lang === "ar" ? "دعم كامل لجميع التطبيقات" : "All Apps Supported"}</h4>
                        <p className="text-[10px] opacity-45 leading-relaxed">{lang === "ku_ba" ? "هەمی بەرنامە و یاریێن دەرەکی ب دروستی کار دکەن" : lang === "ku_so" ? "سەرجەم یاری و بەرنامە دەرەکییەکان کار دەکەن" : lang === "ar" ? "جميع الألعاب والتطبيقات المعدلة تعمل بنجاح" : "All custom injected games & apps work flawlessly"}</p>
                      </div>
                    </div>

                    <a 
                      href="https://t.me/RAkIRD1"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full py-4 rounded-2xl flex items-center justify-center gap-2 font-black text-xs uppercase tracking-wider text-white transition-all active:scale-95 shadow-lg shadow-amber-500/10 hover:shadow-amber-500/20 mt-4 block text-center"
                      style={{ backgroundColor: "#f59e0b" }}
                    >
                      <Send size={14} className="shrink-0" />
                      <span>
                        {lang === "ku_ba" ? "پەیوەندی دگەل تێلیگرامی بۆ کڕینێ" : lang === "ku_so" ? "پەیوەندی لەگەڵ تێلیگرام بۆ کڕین" : lang === "ar" ? "تواصل عبر تليجرام للشراء الفوري" : "Contact on Telegram to Buy"}
                      </span>
                    </a>

                    {/* VIP Certified Apps List */}
                    <div className="space-y-3 pt-4 border-t border-zinc-800/40">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-1.5">
                          <Zap size={13} className="text-amber-400 fill-current" />
                          <span className="text-[10px] font-black uppercase tracking-wider text-zinc-200">
                            {lang === "ku_ba" 
                              ? "بەرنامێنن VIP یێن کارا" 
                              : lang === "ku_so" 
                              ? "بەرنامەکانی VIP" 
                              : lang === "ar" 
                              ? "تطبيقات الـ VIP المتاحة" 
                              : "VIP Certified Apps"}
                          </span>
                        </div>
                        <span className="text-[8px] font-mono text-amber-400/80 uppercase font-bold">
                          {APPS.length} Apps
                        </span>
                      </div>

                      <div className="space-y-2 max-h-[200px] overflow-y-auto pr-1 scrollbar-thin">
                        {APPS.map((app) => (
                          <div 
                            key={`vip-${app.id}`} 
                            className="p-2.5 rounded-2xl bg-zinc-900/60 border border-amber-500/20 flex items-center justify-between gap-3 hover:border-amber-500/40 transition-all"
                          >
                            <div className="flex items-center gap-2.5 min-w-0">
                              <img src={app.icon} className="w-9 h-9 rounded-xl object-cover shrink-0 border border-zinc-800" referrerPolicy="no-referrer" />
                              <div className="min-w-0">
                                <h5 className="text-xs font-black truncate text-zinc-100">{app.name}</h5>
                                <p className="text-[8px] font-bold opacity-40 uppercase tracking-wider">{app.category} • {app.size}</p>
                              </div>
                            </div>

                            <div className="flex items-center gap-1.5 shrink-0">
                              <button
                                onClick={() => {
                                  setCustomAppName(app.name);
                                  setShowIosInstallSim(true);
                                }}
                                className="px-2.5 py-1.5 rounded-xl text-[9px] font-black uppercase tracking-wider bg-amber-400 text-black hover:bg-amber-300 transition-all flex items-center gap-1 active:scale-95 shadow-sm"
                              >
                                <Zap size={10} className="fill-current" />
                                <span>{lang === "ar" ? "تثبيت" : "Install"}</span>
                              </button>

                              <button
                                onClick={() => {
                                  const nameToUse = app.name;
                                  const content = `RAKurd.store VIP Signed IPA\nAppName: ${nameToUse}\nCert: VIP Anti-Revoke\nStatus: Active`;
                                  const blob = new Blob([content], { type: "application/octet-stream" });
                                  const url = URL.createObjectURL(blob);
                                  const a = document.createElement("a");
                                  a.href = url;
                                  a.download = `[RAKurd_VIP]_${nameToUse.replace(/\s+/g, "_")}.ipa`;
                                  document.body.appendChild(a);
                                  a.click();
                                  document.body.removeChild(a);
                                  URL.revokeObjectURL(url);
                                }}
                                className="p-1.5 rounded-xl bg-zinc-800 text-zinc-300 hover:text-white hover:bg-zinc-750 transition-all border border-zinc-700/50"
                                title="Download IPA"
                              >
                                <FileDown size={11} />
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                ) : certTab === "info" ? (
                  /* Public Free Cert Info Tab (with Direct Certificate Selector & File Downloads) */
                  <div className="space-y-5 mb-6">
                    {/* Active Selected Certificate Block on Top */}
                    {(() => {
                      const activeCert = FREE_CERTIFICATES.find(c => c.id === selectedFreeCertId) || FREE_CERTIFICATES[0];
                      return (
                        <div className="rounded-3xl border border-emerald-500/20 bg-emerald-500/[0.02] p-5 space-y-4 relative overflow-hidden">
                          {/* Decorative subtle background mesh */}
                          <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-500/5 rounded-full blur-2xl pointer-events-none" />

                          <div>
                            <span className="text-[8px] font-black uppercase tracking-widest text-emerald-400 bg-emerald-500/10 px-2.5 py-1 rounded-full inline-block mb-2">
                              {lang === "ku_ba" ? "باوەرناما کارا یا هەلبژارتی" : lang === "ku_so" ? "باوەرنامەی چالاکی هەڵبژێردراو" : lang === "ar" ? "الشهادة النشطة المحددة" : "Active Selected Certificate"}
                            </span>
                            <h4 className="text-sm font-black italic tracking-tight text-white leading-snug">
                              {activeCert.name}
                            </h4>
                            <p className="text-[9px] opacity-45 mt-1 font-mono">
                              ID: RAKurd-Public-{activeCert.id.toUpperCase()}
                            </p>
                          </div>

                          {/* Quick File Downloads Grid */}
                          <div className="grid grid-cols-2 gap-2">
                            {/* P12 Download Button */}
                            <button
                              onClick={() => {
                                const content = `RAKurd.store Public Certificate File (.p12)\nName: ${activeCert.name}\nPassword: ${activeCert.password}\nStatus: Active`;
                                const blob = new Blob([content], { type: "application/octet-stream" });
                                const url = URL.createObjectURL(blob);
                                const a = document.createElement("a");
                                a.href = url;
                                a.download = activeCert.p12FileName;
                                document.body.appendChild(a);
                                a.click();
                                document.body.removeChild(a);
                                URL.revokeObjectURL(url);
                              }}
                              className="py-3 px-3 rounded-xl flex items-center justify-center gap-1.5 font-black text-[9px] uppercase tracking-wider text-white transition-all bg-zinc-900 border border-zinc-800/80 hover:bg-zinc-850 active:scale-95"
                            >
                              <FileDown size={11} className="text-emerald-400" />
                              <span className="truncate">Download .p12</span>
                            </button>

                            {/* Mobileprovision Download Button */}
                            <button
                              onClick={() => {
                                const content = `RAKurd.store Mobileprovision Profile\nAssociated with: ${activeCert.name}\nUDID Shield: Enabled`;
                                const blob = new Blob([content], { type: "application/octet-stream" });
                                const url = URL.createObjectURL(blob);
                                const a = document.createElement("a");
                                a.href = url;
                                a.download = activeCert.provFileName;
                                document.body.appendChild(a);
                                a.click();
                                document.body.removeChild(a);
                                URL.revokeObjectURL(url);
                              }}
                              className="py-3 px-3 rounded-xl flex items-center justify-center gap-1.5 font-black text-[9px] uppercase tracking-wider text-white transition-all bg-zinc-900 border border-zinc-800/80 hover:bg-zinc-850 active:scale-95"
                            >
                              <Download size={11} className="text-emerald-400" />
                              <span className="truncate">Download Mobileprovision</span>
                            </button>
                          </div>

                          {/* Password Copy Area */}
                          <div className="bg-black/40 border border-zinc-800/60 p-2.5 rounded-xl flex items-center justify-between gap-3">
                            <div className="flex items-center gap-2 font-mono text-[10px]">
                              <Lock size={10} className="text-emerald-500 shrink-0" />
                              <span className="opacity-45 text-[9px]">
                                {lang === "ar" ? "كلمة المرور:" : "Password:"}
                              </span>
                              <span className="font-bold text-zinc-100 select-all px-1.5 py-0.5 bg-zinc-900 rounded border border-zinc-800">
                                {activeCert.password}
                              </span>
                            </div>
                            <button
                              onClick={() => {
                                navigator.clipboard.writeText(activeCert.password);
                                setCopiedPasswordId(activeCert.id);
                                setTimeout(() => setCopiedPasswordId(""), 1500);
                              }}
                              className="px-2.5 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-wider bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 hover:bg-emerald-500/20 active:scale-95 transition-all flex items-center gap-1 shrink-0"
                            >
                              {copiedPasswordId === activeCert.id ? (
                                <>
                                  <Check size={10} strokeWidth={4} />
                                  <span>{lang === "ar" ? "تم النسخ" : "Copied"}</span>
                                </>
                              ) : (
                                <>
                                  <Copy size={10} />
                                  <span>{lang === "ar" ? "نسخ" : "Copy"}</span>
                                </>
                              )}
                            </button>
                          </div>
                        </div>
                      );
                    })()}

                    {/* Choose Certificate Section (With list grid) */}
                    <div className="space-y-2.5">
                      <div className="flex items-center gap-1.5 pb-1 border-b border-zinc-800/20">
                        <Info size={11} className="text-emerald-400" />
                        <span className="text-[9px] font-black uppercase tracking-wider opacity-60">
                          {lang === "ku_ba" 
                            ? "باوەرنامەکێ ژ لیستا خوارێ هەلبژێرە:" 
                            : lang === "ku_so" 
                            ? "باوەرنامەیەک لە لیستی خوارەوە هەڵبژێرە:" 
                            : lang === "ar" 
                            ? "اختر شهادة من القائمة أدناه:" 
                            : "Choose a Certificate from the List Below:"}
                        </span>
                      </div>

                      <div className="grid grid-cols-1 gap-2">
                        {FREE_CERTIFICATES.map((cert) => {
                          const isSelected = selectedFreeCertId === cert.id;
                          return (
                            <div
                              key={cert.id}
                              onClick={() => {
                                setSelectedFreeCertId(cert.id);
                                setCopiedPasswordId("");
                              }}
                              className={`p-3.5 rounded-2xl border text-left cursor-pointer transition-all flex justify-between items-center gap-4 ${
                                isSelected 
                                  ? "bg-emerald-500/[0.03] border-emerald-500/40 shadow-md shadow-emerald-500/[0.02]" 
                                  : "bg-zinc-900/30 border-zinc-800/60 hover:bg-zinc-900/50 hover:border-zinc-800"
                              }`}
                            >
                              <div className="space-y-1 min-w-0">
                                <h5 className={`text-xs font-black truncate ${isSelected ? "text-emerald-400" : "text-zinc-200"}`}>
                                  {cert.name}
                                </h5>
                                <div className="flex items-center gap-2">
                                  <span className={`text-[7px] font-black uppercase tracking-wider px-1.5 py-0.5 rounded ${
                                    isSelected 
                                      ? "bg-emerald-500/10 text-emerald-400" 
                                      : "bg-zinc-800 text-zinc-400"
                                  }`}>
                                    {cert.statusText[lang] || cert.statusText.en}
                                  </span>
                                  <span className="text-[8px] opacity-35 font-mono">
                                    PW: {cert.password}
                                  </span>
                                </div>
                              </div>

                              <div className="flex items-center gap-1 shrink-0">
                                <div className={`w-6 h-6 rounded-lg flex items-center justify-center border transition-all ${
                                  isSelected 
                                    ? "bg-emerald-500/20 border-emerald-500/40 text-emerald-400" 
                                    : "bg-zinc-900/60 border-zinc-800 text-zinc-500"
                                }`}>
                                  <Check size={11} strokeWidth={isSelected ? 4 : 2} className={isSelected ? "scale-110" : "opacity-0"} />
                                </div>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>

                    {/* Warnings and direct install button */}
                    <div className="pt-3 border-t border-zinc-800/30 space-y-4">
                      {/* Free Certificate Signed Apps List */}
                      <div className="space-y-3 pt-2">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-1.5">
                            <Zap size={13} className="text-emerald-400 fill-current" />
                            <span className="text-[10px] font-black uppercase tracking-wider text-zinc-200">
                              {lang === "ku_ba" 
                                ? "بەرنامێنن هاتیە ساینکرن ب ڤێ باوەرنامێ" 
                                : lang === "ku_so" 
                                ? "بەرنامەکان باوەرنامەی بێبەرامبەر" 
                                : lang === "ar" 
                                ? "تطبيقات الشهادة المجانية" 
                                : "Free Certificate Signed Apps"}
                            </span>
                          </div>
                          <span className="text-[8px] font-mono text-emerald-400/80 uppercase font-bold">
                            {APPS.length} Apps
                          </span>
                        </div>

                        <div className="space-y-2 max-h-[200px] overflow-y-auto pr-1 scrollbar-thin">
                          {APPS.map((app) => (
                            <div 
                              key={`free-${app.id}`} 
                              className="p-2.5 rounded-2xl bg-zinc-900/60 border border-emerald-500/20 flex items-center justify-between gap-3 hover:border-emerald-500/40 transition-all"
                            >
                              <div className="flex items-center gap-2.5 min-w-0">
                                <img src={app.icon} className="w-9 h-9 rounded-xl object-cover shrink-0 border border-zinc-800" referrerPolicy="no-referrer" />
                                <div className="min-w-0">
                                  <h5 className="text-xs font-black truncate text-zinc-100">{app.name}</h5>
                                  <p className="text-[8px] font-bold opacity-40 uppercase tracking-wider">{app.category} • {app.size}</p>
                                </div>
                              </div>

                              <div className="flex items-center gap-1.5 shrink-0">
                                <button
                                  onClick={() => {
                                    setCustomAppName(app.name);
                                    setShowIosInstallSim(true);
                                  }}
                                  className="px-2.5 py-1.5 rounded-xl text-[9px] font-black uppercase tracking-wider bg-emerald-400 text-black hover:bg-emerald-300 transition-all flex items-center gap-1 active:scale-95 shadow-sm"
                                >
                                  <Zap size={10} className="fill-current" />
                                  <span>{lang === "ar" ? "تثبيت" : "Install"}</span>
                                </button>

                                <button
                                  onClick={() => {
                                    const nameToUse = app.name;
                                    const content = `RAKurd.store Signed IPA\nAppName: ${nameToUse}\nCert: Free Certificate\nStatus: Active`;
                                    const blob = new Blob([content], { type: "application/octet-stream" });
                                    const url = URL.createObjectURL(blob);
                                    const a = document.createElement("a");
                                    a.href = url;
                                    a.download = `[RAKurd]_${nameToUse.replace(/\s+/g, "_")}.ipa`;
                                    document.body.appendChild(a);
                                    a.click();
                                    document.body.removeChild(a);
                                    URL.revokeObjectURL(url);
                                  }}
                                  className="p-1.5 rounded-xl bg-zinc-800 text-zinc-300 hover:text-white hover:bg-zinc-750 transition-all border border-zinc-700/50"
                                  title="Download IPA"
                                >
                                  <FileDown size={11} />
                                </button>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>

                      {isCertSigning ? (
                        <div className="p-4 rounded-2xl bg-zinc-900/60 dark:bg-zinc-900/30 border border-zinc-800/40">
                          <div className="flex justify-between items-center mb-2">
                            <span className="text-[9px] font-black uppercase tracking-wider text-emerald-400 animate-pulse">
                              {certSignProgress < 40 ? "Connecting Server..." : certSignProgress < 80 ? "Applying Signature..." : "Preparing Manifest..."}
                            </span>
                            <span className="text-xs font-mono font-black text-emerald-400">{certSignProgress}%</span>
                          </div>
                          <div className="w-full bg-zinc-800 rounded-full h-1.5 overflow-hidden">
                            <motion.div 
                              className="h-full bg-emerald-500" 
                              animate={{ width: `${certSignProgress}%` }}
                              transition={{ duration: 0.1 }}
                            />
                          </div>
                        </div>
                      ) : (
                        <button 
                          onClick={() => setIsCertSigning(true)}
                          className="w-full py-3.5 rounded-2xl flex items-center justify-center gap-2 font-black text-xs uppercase tracking-wider text-white transition-all active:scale-95 shadow-lg shadow-emerald-500/10 hover:shadow-emerald-500/20"
                          style={{ backgroundColor: "#10b981" }}
                        >
                          <Zap size={13} className="shrink-0 fill-current" />
                          <span>
                            {lang === "ku_ba" ? "دامەزراندنا ڕاستەوخۆ یا باوەرنامێ" : lang === "ku_so" ? "دامەزراندنی ڕاستەوخۆی باوەرنامە" : lang === "ar" ? "تثبيت الشهادة المباشر" : "Direct Auto Install Certificate"}
                          </span>
                        </button>
                      )}
                    </div>
                  </div>
                ) : (
                  /* Premium Custom IPA Web Signer Tab */
                  <div className="space-y-4">
                    {customSignState === "idle" ? (
                      /* Step 1: Input Form */
                      <div className="space-y-4">
                        <div className="flex justify-between items-center bg-zinc-900/40 border border-zinc-800/50 p-3 rounded-2xl">
                          <div>
                            <h4 className="text-[10px] font-black uppercase text-emerald-400">RAKurd Sign Engine</h4>
                            <p className="text-[9px] opacity-50">{signerTranslations[lang]?.signerDesc || signerTranslations.en.signerDesc}</p>
                          </div>
                          <button 
                            type="button"
                            onClick={handleFillDemoSigner}
                            className="px-2.5 py-1 rounded-lg text-[8px] font-black uppercase tracking-wider bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 hover:bg-emerald-500/20 active:scale-95 transition-all flex items-center gap-1 shrink-0"
                          >
                            <Bot size={10} />
                            <span>{signerTranslations[lang]?.fillDemo || signerTranslations.en.fillDemo}</span>
                          </button>
                        </div>

                        {/* Certificate File (.p12) Upload */}
                        <div className="space-y-1.5">
                          <label className={`text-[9px] font-black uppercase tracking-wider transition-colors duration-300 ${signerErrors.p12 ? 'text-red-500' : 'opacity-60'}`}>
                            {signerTranslations[lang]?.p12Label || signerTranslations.en.p12Label} <span className="text-red-500">*</span>
                          </label>
                          <div className={`border-2 border-dashed rounded-2xl p-4 flex flex-col items-center justify-center relative cursor-pointer transition-all duration-300 ${
                            signerErrors.p12 
                              ? "border-red-500/80 bg-red-500/5 animate-pulse shadow-[0_0_15px_rgba(239,68,68,0.1)]" 
                              : customP12Name 
                              ? "border-emerald-500/40 bg-emerald-500/5" 
                              : "border-zinc-800 bg-zinc-900/20 hover:border-emerald-500/40"
                          }`}>
                            <input 
                              type="file" 
                              accept=".p12"
                              className="absolute inset-0 opacity-0 cursor-pointer"
                              onChange={(e) => {
                                const file = e.target.files?.[0];
                                if (file) {
                                  setCustomP12(file);
                                  setCustomP12Name(file.name);
                                  setSignerErrors(prev => ({ ...prev, p12: false }));
                                }
                              }}
                            />
                            <Upload size={20} className={signerErrors.p12 ? "text-red-500" : customP12Name ? "text-emerald-400" : "text-zinc-500"} />
                            <span className={`text-[10px] font-bold mt-1 text-center truncate max-w-full px-2 ${signerErrors.p12 ? 'text-red-400' : ''}`}>
                              {customP12Name || "drag_drop_p12"}
                            </span>
                          </div>
                          {signerErrors.p12 && (
                            <span className="text-[9px] font-black text-red-500 block mt-0.5 animate-pulse">
                              {lang === "ku_ba" ? "دڤێت فایلی .p12 بارکەی!" : lang === "ku_so" ? "پێویستە فایلی .p12 باربکەیت!" : lang === "ar" ? "يجب رفع ملف الشهادة .p12!" : ".p12 certificate file is required!"}
                            </span>
                          )}
                        </div>

                        {/* Provisioning Profile (.mobileprovision) Upload */}
                        <div className="space-y-1.5">
                          <label className={`text-[9px] font-black uppercase tracking-wider transition-colors duration-300 ${signerErrors.prov ? 'text-red-500' : 'opacity-60'}`}>
                            {signerTranslations[lang]?.provLabel || signerTranslations.en.provLabel} <span className="text-red-500">*</span>
                          </label>
                          <div className={`border-2 border-dashed rounded-2xl p-4 flex flex-col items-center justify-center relative cursor-pointer transition-all duration-300 ${
                            signerErrors.prov 
                              ? "border-red-500/80 bg-red-500/5 animate-pulse shadow-[0_0_15px_rgba(239,68,68,0.1)]" 
                              : customProvName 
                              ? "border-emerald-500/40 bg-emerald-500/5" 
                              : "border-zinc-800 bg-zinc-900/20 hover:border-emerald-500/40"
                          }`}>
                            <input 
                              type="file" 
                              accept=".mobileprovision"
                              className="absolute inset-0 opacity-0 cursor-pointer"
                              onChange={(e) => {
                                const file = e.target.files?.[0];
                                if (file) {
                                  setCustomProv(file);
                                  setCustomProvName(file.name);
                                  setSignerErrors(prev => ({ ...prev, prov: false }));
                                }
                              }}
                            />
                            <Upload size={20} className={signerErrors.prov ? "text-red-500" : customProvName ? "text-emerald-400" : "text-zinc-500"} />
                            <span className={`text-[10px] font-bold mt-1 text-center truncate max-w-full px-2 ${signerErrors.prov ? 'text-red-400' : ''}`}>
                              {customProvName || "drag_drop_provision"}
                            </span>
                          </div>
                          {signerErrors.prov && (
                            <span className="text-[9px] font-black text-red-500 block mt-0.5 animate-pulse">
                              {lang === "ku_ba" ? "دڤێت فایلی .mobileprovision بارکەی!" : lang === "ku_so" ? "پێویستە فایلی .mobileprovision باربکەیت!" : lang === "ar" ? "يجب رفع ملف التعريف .mobileprovision!" : ".mobileprovision file is required!"}
                            </span>
                          )}
                        </div>

                        {/* Certificate Password */}
                        <div className="space-y-1.5">
                          <label className={`text-[9px] font-black uppercase tracking-wider transition-colors duration-300 ${signerErrors.password ? 'text-red-500' : 'opacity-60'}`}>
                            {signerTranslations[lang]?.passwordLabel || signerTranslations.en.passwordLabel} <span className="text-red-500">*</span>
                          </label>
                          <div className="relative">
                            <span className={`absolute left-3.5 top-1/2 -translate-y-1/2 transition-colors duration-300 ${signerErrors.password ? 'text-red-500' : 'text-zinc-500'}`}>
                              <Lock size={12} />
                            </span>
                            <input 
                              type="password"
                              value={customPassword}
                              onChange={(e) => {
                                setCustomPassword(e.target.value);
                                setSignerErrors(prev => ({ ...prev, password: false, passwordMsg: "" }));
                              }}
                              placeholder="e.g. 123456"
                              className={`w-full rounded-xl py-2.5 pl-9 pr-4 text-xs font-black placeholder:opacity-40 outline-none transition-all duration-300 ${
                                signerErrors.password 
                                  ? "bg-red-500/5 border border-red-500/80 text-red-400 focus:border-red-500 shadow-[0_0_15px_rgba(239,68,68,0.1)]" 
                                  : "bg-zinc-900/60 dark:bg-zinc-900/30 border border-zinc-800 text-white focus:border-emerald-500/50"
                              }`}
                            />
                          </div>
                          {signerErrors.password && (
                            <span className="text-[9px] font-black text-red-500 block mt-0.5 animate-pulse">
                              {signerErrors.passwordMsg}
                            </span>
                          )}
                        </div>

                        {/* App Custom Name */}
                        <div className="space-y-1.5">
                          <label className="text-[9px] font-black uppercase tracking-wider opacity-60">
                            {signerTranslations[lang]?.appNameLabel || signerTranslations.en.appNameLabel}
                          </label>
                          <input 
                            type="text"
                            value={customAppName}
                            onChange={(e) => setCustomAppName(e.target.value)}
                            placeholder="e.g. Instagram++"
                            className="w-full bg-zinc-900/60 dark:bg-zinc-900/30 border border-zinc-800 rounded-xl py-2.5 px-4 text-xs font-black placeholder:opacity-40 focus:border-emerald-500/50 outline-none"
                          />
                        </div>

                        {/* IPA File Upload or Popular App Select */}
                        <div className="space-y-2 pt-2 border-t border-zinc-800/40">
                          <div className="flex justify-between items-center">
                            <label className="text-[9px] font-black uppercase tracking-wider opacity-60">
                              {signerTranslations[lang]?.ipaLabel || signerTranslations.en.ipaLabel}
                            </label>
                            {customIpaName && (
                              <button 
                                onClick={() => { setCustomIpa(null); setCustomIpaName(""); }}
                                className="text-[8px] text-red-500 uppercase font-black tracking-wider"
                              >
                                {lang === "ar" ? "إزالة" : "Remove"}
                              </button>
                            )}
                          </div>

                          <div className={`border-2 border-dashed rounded-2xl p-4 flex flex-col items-center justify-center relative cursor-pointer hover:border-emerald-500/40 transition-colors ${
                            customIpaName ? "border-emerald-500/40 bg-emerald-500/5" : "border-zinc-800 bg-zinc-900/20"
                          }`}>
                            <input 
                              type="file" 
                              accept=".ipa"
                              className="absolute inset-0 opacity-0 cursor-pointer"
                              onChange={(e) => {
                                const file = e.target.files?.[0];
                                if (file) {
                                  setCustomIpa(file);
                                  setCustomIpaName(file.name);
                                  // Auto-fill app name from file name
                                  if (!customAppName) {
                                    setCustomAppName(file.name.replace(".ipa", "").replace(/_|-/g, " "));
                                  }
                                }
                              }}
                            />
                            <Download size={20} className={customIpaName ? "text-emerald-400" : "text-zinc-500"} />
                            <span className="text-[10px] font-bold mt-1 text-center truncate max-w-full px-2">
                              {customIpaName || "Upload Custom Game/App IPA"}
                            </span>
                          </div>

                          {/* Popular Apps selection */}
                          <div className="space-y-1 pt-1">
                            <span className="text-[8px] font-black uppercase tracking-wider opacity-45">
                              {signerTranslations[lang]?.selectApp || signerTranslations.en.selectApp}
                            </span>
                            <div className="flex flex-wrap gap-1.5">
                              {POPULAR_SIGN_APPS.map((pApp) => (
                                <button
                                  key={pApp.id}
                                  type="button"
                                  onClick={() => {
                                    setSelectedPopularApp(pApp.id);
                                    setCustomAppName(pApp.name);
                                  }}
                                  className={`px-3 py-1.5 rounded-lg text-[9px] font-black uppercase transition-all border ${
                                    selectedPopularApp === pApp.id 
                                      ? "bg-emerald-500/20 text-emerald-400 border-emerald-500/55" 
                                      : "bg-zinc-900/60 border-zinc-800 text-zinc-400 hover:text-white"
                                  }`}
                                >
                                  {pApp.name}
                                </button>
                              ))}
                            </div>
                          </div>
                        </div>

                        {/* Dynamic Signer Actions: When certificates are entered and password is correct, immediately show Download & Install buttons! */}
                        {isSignerReady ? (
                          <div className="space-y-3 pt-4 border-t border-zinc-800/20 dark:border-zinc-800/40 animate-in fade-in duration-300">
                            {/* Certificate Loaded successfully status badge */}
                            <div className="flex items-center gap-2 justify-center bg-emerald-500/10 border border-emerald-500/20 p-2.5 rounded-xl text-emerald-400">
                              <ShieldCheck size={14} className="animate-pulse" />
                              <span className="text-[10px] font-black uppercase tracking-wider">
                                {lang === "ku_ba" ? "باوەرنامە ب سەرکەفتی هاتە بارکرن!" : lang === "ku_so" ? "باوەرنامەکە بە سەرکەوتوویی بارکرا!" : lang === "ar" ? "تم تحميل الشهادة بنجاح!" : "Certificate Loaded Successfully!"}
                              </span>
                            </div>

                            <div className="grid grid-cols-2 gap-2">
                              {/* Button 1: Download IPA */}
                              <button
                                onClick={() => {
                                  // Dynamically create signed IPA and download
                                  const nameToUse = customAppName || "RAKurd_Signed_App";
                                  const content = `RAKurd.store Premium Signed IPA\nAppName: ${nameToUse}\nSignature: SHA-256 Validated\nCert: ${customP12Name || "RAKurd_Certificate.p12"}\nActive bypass framework successfully injected.`;
                                  const blob = new Blob([content], { type: "application/octet-stream" });
                                  const url = URL.createObjectURL(blob);
                                  const a = document.createElement("a");
                                  a.href = url;
                                  a.download = `[RAKurd.store]_${nameToUse.replace(/\s+/g, "_")}.ipa`;
                                  document.body.appendChild(a);
                                  a.click();
                                  document.body.removeChild(a);
                                  URL.revokeObjectURL(url);
                                }}
                                className="w-full py-4 rounded-2xl flex items-center justify-center gap-2 font-black text-[10px] uppercase tracking-wider text-white transition-all active:scale-95 shadow-lg bg-zinc-900 border border-zinc-800 hover:bg-zinc-850 hover:border-zinc-700"
                              >
                                <FileDown size={14} className="shrink-0 text-emerald-400" />
                                <span>
                                  {signerTranslations[lang]?.dlIpa || signerTranslations.en.dlIpa}
                                </span>
                              </button>

                              {/* Button 2: Direct Install */}
                              <button
                                onClick={() => setShowIosInstallSim(true)}
                                className="w-full py-4 rounded-2xl flex items-center justify-center gap-2 font-black text-[10px] uppercase tracking-wider text-black transition-all active:scale-95 shadow-lg bg-emerald-400 hover:bg-emerald-300"
                              >
                                <Zap size={14} className="shrink-0 fill-current" />
                                <span>
                                  {signerTranslations[lang]?.directInstall || signerTranslations.en.directInstall}
                                </span>
                              </button>
                            </div>

                            {/* Reset Certificate Form */}
                            <button
                              onClick={handleResetSigner}
                              className="w-full py-2 rounded-xl text-center text-[9px] font-black uppercase tracking-wider text-zinc-500 hover:text-zinc-300 transition-colors"
                            >
                              {lang === "ar" ? "توقيع تطبيق آخر" : "Sign Another App"}
                            </button>
                          </div>
                        ) : (
                          /* Standard Sign Button (shown if files or password are not ready/valid yet) */
                          <button
                            onClick={() => {
                              const errors: { p12?: boolean; prov?: boolean; password?: boolean; passwordMsg?: string } = {};
                              
                              if (!customP12Name) {
                                errors.p12 = true;
                              }
                              if (!customProvName) {
                                errors.prov = true;
                              }
                              if (!customPassword) {
                                errors.password = true;
                                errors.passwordMsg = 
                                  lang === "ku_ba" ? "تکایە پاسوۆردێ بنڤیسە!" :
                                  lang === "ku_so" ? "تکایە پاسوۆردەکە بنووسە!" :
                                  lang === "ar" ? "يرجى إدخال كلمة المرور!" :
                                  "Password is required!";
                              } else if (customPassword !== "rakurd.store") {
                                errors.password = true;
                                errors.passwordMsg = 
                                  lang === "ku_ba" ? "پاسوۆردێ باوەرنامێ خەلەتە! ژ کەرەما خۆ دیسان تاقی بکە." :
                                  lang === "ku_so" ? "پاسوۆردی باوەرنامەکە هەڵەیە! تکایە دووبارە تاقی بکەرەوە." :
                                  lang === "ar" ? "كلمة مرور الشهادة غير صحيحة! يرجى المحاولة مرة أخرى." :
                                  "Incorrect certificate password! Please try again.";
                              }

                              if (Object.keys(errors).length > 0) {
                                setSignerErrors(errors);
                                return;
                              }
                            }}
                            className="w-full py-4 rounded-2xl flex items-center justify-center gap-2 font-black text-xs uppercase tracking-wider text-white transition-all active:scale-95 shadow-lg shadow-emerald-500/10 hover:shadow-emerald-500/20 mt-4"
                            style={{ backgroundColor: "#10b981" }}
                          >
                            <ShieldCheck size={16} />
                            <span>
                              {signerTranslations[lang]?.signBtn || signerTranslations.en.signBtn}
                            </span>
                          </button>
                        )}
                      </div>
                    ) : isCustomSigning ? (
                      /* Step 2: Signing Progress Animation */
                      <div className="py-8 flex flex-col items-center justify-center text-center">
                        <div className="relative mb-6">
                          {/* Outer pulsating concentric circle */}
                          <div className="absolute inset-0 rounded-full border border-emerald-500/30 animate-ping" />
                          <div className="w-24 h-24 rounded-full bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center relative">
                            <Shield className="text-emerald-400 w-10 h-10 animate-pulse" />
                            {/* Spinning loader */}
                            <svg className="absolute inset-0 w-full h-full -rotate-90">
                              <circle 
                                cx="48" 
                                cy="48" 
                                r="44" 
                                stroke="currentColor" 
                                className="text-emerald-500"
                                strokeWidth="4" 
                                fill="transparent" 
                                strokeDasharray={2 * Math.PI * 44}
                                strokeDashoffset={2 * Math.PI * 44 * (1 - customSignProgress / 100)}
                              />
                            </svg>
                          </div>
                          <span className="absolute -bottom-2 left-1/2 -translate-x-1/2 bg-emerald-500 text-black font-mono font-black text-xs px-2 py-0.5 rounded-full shadow">
                            {customSignProgress}%
                          </span>
                        </div>

                        <h4 className="text-sm font-black uppercase tracking-wide text-emerald-400 mb-1 animate-pulse">
                          {customSignState === "uploading" && (signerTranslations[lang]?.signingUp || signerTranslations.en.signingUp)}
                          {customSignState === "signing" && (signerTranslations[lang]?.signingExec || signerTranslations.en.signingExec)}
                          {customSignState === "packaging" && (signerTranslations[lang]?.signingPack || signerTranslations.en.signingPack)}
                        </h4>
                        <p className="text-[10px] opacity-45 leading-relaxed max-w-[80%] mx-auto">
                          {lang === "ku_ba" 
                            ? "سیستەمێ RAKurd خەریکە لایەرێن پاراستنێ زێدە دکەت..." 
                            : lang === "ku_so" 
                            ? "سیستەمی RAKurd خەریکە دژی ڕیڤۆک پاراستن دادەنێت..." 
                            : lang === "ar" 
                            ? "خوادم RAKurd تقوم بتهيئة جدران الحماية للشهادة..." 
                            : "Injecting anti-revoke hooks and signing local app binaries securely."}
                        </p>
                      </div>
                    ) : (
                      /* Step 3: SUCCESS & DOWNLOAD SCREEN (Link Protection Enabled) */
                      <div 
                        className="space-y-4 select-none"
                        onContextMenu={(e) => e.preventDefault()}
                        onCopy={(e) => {
                          e.preventDefault();
                          alert("Link copying disabled for RAKurd.store security. Please use direct download/install buttons.");
                        }}
                      >
                        <div className="flex flex-col items-center text-center py-4 bg-emerald-500/5 border border-emerald-500/25 p-4 rounded-[2rem] relative">
                          <div className="w-12 h-12 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mb-3">
                            <Check size={24} strokeWidth={3} className="animate-bounce" />
                          </div>
                          <h4 className="text-base font-black italic tracking-tight uppercase text-emerald-400">
                            {signerTranslations[lang]?.successTitle || signerTranslations.en.successTitle}
                          </h4>
                          <p className="text-[10px] opacity-60 leading-relaxed mt-2 max-w-[90%] text-balance">
                            {signerTranslations[lang]?.successDesc || signerTranslations.en.successDesc}
                          </p>

                          {/* App signature info card */}
                          <div className="w-full bg-black/40 border border-zinc-800/60 rounded-xl p-3 mt-4 text-left space-y-1.5 font-mono text-[9px]">
                            <div className="flex justify-between">
                              <span className="opacity-45">Signed App:</span>
                              <span className="font-black text-zinc-100">{customAppName || "RAKurd Signed App"}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="opacity-45">Cert File:</span>
                              <span className="font-black text-zinc-100 truncate max-w-[150px]">{customP12Name}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="opacity-45">Engine:</span>
                              <span className="font-black text-amber-400 uppercase tracking-widest">RAKurd Active Shield</span>
                            </div>
                          </div>
                        </div>

                        {/* Copy-protected Premium Action Buttons */}
                        <div className="space-y-2.5 pt-2">
                          {/* Button 1: Download IPA */}
                          <button
                            onClick={() => {
                              // Dynamically create a mock file in memory and download it
                              const nameToUse = customAppName || "RAKurd_Signed_App";
                              const content = `RAKurd.store Premium Signed IPA\nAppName: ${nameToUse}\nSignature: SHA-256 Validated\nCert: ${customP12Name}\nActive bypass framework successfully injected.`;
                              const blob = new Blob([content], { type: "application/octet-stream" });
                              const url = URL.createObjectURL(blob);
                              const a = document.createElement("a");
                              a.href = url;
                              a.download = `[RAKurd.store]_${nameToUse.replace(/\s+/g, "_")}.ipa`;
                              document.body.appendChild(a);
                              a.click();
                              document.body.removeChild(a);
                              URL.revokeObjectURL(url);
                            }}
                            className="w-full py-4 rounded-2xl flex items-center justify-center gap-2 font-black text-xs uppercase tracking-wider text-white transition-all active:scale-95 shadow-lg bg-zinc-900 border border-zinc-800 hover:bg-zinc-850 hover:border-zinc-700"
                          >
                            <FileDown size={14} className="shrink-0 text-emerald-400" />
                            <span>
                              {signerTranslations[lang]?.dlIpa || signerTranslations.en.dlIpa}
                            </span>
                          </button>

                          {/* Button 2: Direct Install with simulated iOS popup */}
                          <button
                            onClick={() => setShowIosInstallSim(true)}
                            className="w-full py-4 rounded-2xl flex items-center justify-center gap-2 font-black text-xs uppercase tracking-wider text-black transition-all active:scale-95 shadow-lg bg-emerald-400 hover:bg-emerald-300"
                          >
                            <Zap size={14} className="shrink-0 fill-current" />
                            <span>
                              {signerTranslations[lang]?.directInstall || signerTranslations.en.directInstall}
                            </span>
                          </button>
                        </div>

                        {/* Lock Warning Notice */}
                        <div className="flex items-center gap-2 p-3 rounded-xl bg-zinc-950/80 border border-zinc-900 text-center justify-center">
                          <Lock size={10} className="text-amber-500 shrink-0" />
                          <span className="text-[8px] font-black uppercase text-amber-500 tracking-wider">
                            {signerTranslations[lang]?.securedNotice || signerTranslations.en.securedNotice}
                          </span>
                        </div>

                        <button
                          onClick={handleResetSigner}
                          className="w-full py-2.5 rounded-xl text-center text-[9px] font-black uppercase tracking-wider text-zinc-500 hover:text-zinc-300 transition-colors"
                        >
                          {lang === "ar" ? "توقيع تطبيق آخر" : "Sign Another App"}
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Simulated native iOS Install Alert Dialog */}
      <AnimatePresence>
        {showIosInstallSim && (
          <div className="fixed inset-0 z-[3000] flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm">
            <motion.div
              initial={{ scale: 0.85, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.85, opacity: 0 }}
              className="w-full max-w-[270px] bg-[#f2f2f2] dark:bg-[#1c1c1e] text-black dark:text-white rounded-[14px] overflow-hidden shadow-2xl flex flex-col font-sans select-none"
            >
              <div className="p-4 flex flex-col items-center text-center">
                <span className="text-sm font-semibold leading-tight">
                  "dl.rakurd.store"
                </span>
                <span className="text-xs mt-1 text-[#3a3a3c] dark:text-[#d1d1d6] leading-snug">
                  {lang === "ku_ba" 
                    ? `دڤێت بەرنامێ "${customAppName || "RAKurd Signed App"}" دابەزینیت؟` 
                    : lang === "ku_so" 
                    ? `دەیەوێت بەرنامەی "${customAppName || "RAKurd Signed App"}" دابەزێنێت؟` 
                    : lang === "ar" 
                    ? `يرغب في تثبيت "${customAppName || "RAKurd Signed App"}"` 
                    : `would like to install "${customAppName || "RAKurd Signed App"}"`}
                </span>
              </div>
              <div className="flex border-t border-[#c6c6c8] dark:border-[#3a3a3c] h-[44px] divide-x divide-[#c6c6c8] dark:divide-[#3a3a3c]">
                <button
                  onClick={() => setShowIosInstallSim(false)}
                  className="flex-1 text-[#007aff] font-normal text-sm active:bg-[#e5e5ea] dark:active:bg-[#2c2c2e] transition-colors"
                >
                  {lang === "ar" ? "إلغاء" : "Cancel"}
                </button>
                <button
                  onClick={() => {
                    setShowIosInstallSim(false);
                    // Launch the simulated manifest OTA link
                    window.location.href = "itms-services://?action=download-manifest&url=https://pub-b6abf7b6f3404bcfaacf050fc613059a.r2.dev/c6a3c90d-685b-4add-a8b0-d462eabce798/manifest.plist";
                    setTimeout(() => {
                      alert(
                        lang === "ku_ba" 
                          ? "داگرتن دەستپێکر! ژ کەرەما خۆ سەیری سەر شاشا سەرەکی یا مۆبایلێ بکە." 
                          : lang === "ku_so" 
                          ? "داگرتن دەستی پێکرد! تکایە سەیری سەر شاشەی سەرەکی مۆبایلەکەت بکە." 
                          : lang === "ar" 
                          ? "بدأ التثبيت الآن! يرجى مراجعة الشاشة الرئيسية لهاتفك." 
                          : "Installation request successfully sent! Please check your home screen."
                      );
                    }, 500);
                  }}
                  className="flex-1 text-[#007aff] font-semibold text-sm active:bg-[#e5e5ea] dark:active:bg-[#2c2c2e] transition-colors"
                >
                  {lang === "ar" ? "تثبيت" : "Install"}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </ViewContainer>
  );
};

const AppDetailView = ({ app, onClose, accentColor, isDarkMode, lang }: { app: AppItem, onClose: () => void, accentColor: string, isDarkMode: boolean, lang: Language }) => {
  const [installingState, setInstallingState] = useState<"idle" | "connecting" | "signing" | "manifesting" | "ready">("idle");
  const [installProgress, setInstallProgress] = useState(0);
  const [copied, setCopied] = useState(false);
  const [showHowTo, setShowHowTo] = useState(false);

  // New Countdown states
  const [countdownActive, setCountdownActive] = useState(false);
  const [countdownSeconds, setCountdownSeconds] = useState(10);
  const [countdownTotal] = useState(10);
  const [countdownTargetUrl, setCountdownTargetUrl] = useState("");
  const [countdownTriggerType, setCountdownTriggerType] = useState<"ipa" | "install">("ipa");

  const signingIntervalRef = React.useRef<any>(null);

  const isRtl = lang !== "en";

  useEffect(() => {
    let timer: any;
    if (countdownActive && countdownSeconds > 0) {
      timer = setTimeout(() => {
        setCountdownSeconds(prev => prev - 1);
      }, 1000);
    } else if (countdownActive && countdownSeconds === 0) {
      setCountdownActive(false);
      startSigningProcess(countdownTargetUrl);
    }
    return () => clearTimeout(timer);
  }, [countdownActive, countdownSeconds, countdownTargetUrl]);

  useEffect(() => {
    return () => {
      if (signingIntervalRef.current) {
        clearInterval(signingIntervalRef.current);
      }
    };
  }, []);

  const getCountdownTitle = () => {
    if (countdownTriggerType === "ipa") {
      switch (lang) {
        case "ku_ba": return "داگرتنا بەرنامەی (Download IPA)";
        case "ku_so": return "داگرتنی بەرنامە (Download IPA)";
        case "ar": return "تحميل ملف الـ IPA";
        default: return "DOWNLOAD IPA SECURE GATEWAY";
      }
    } else {
      switch (lang) {
        case "ku_ba": return "دامەزراندنا بەرنامەی (Install App)";
        case "ku_so": return "دامەزراندنی بەرنامە (Install App)";
        case "ar": return "تثبيت التطبيق المباشر";
        default: return "DIRECT INSTALL SECURE GATEWAY";
      }
    }
  };

  const getCountdownLabel = () => {
    if (countdownTriggerType === "ipa") {
      switch (lang) {
        case "ku_ba": return "لینکێ داگرتنا IPA دێ هێتە ئامادەکرن پشتی:";
        case "ku_so": return "لیکی داگرتنی IPA ئامادە دەکرێت دوای:";
        case "ar": return "جاري تحضير رابط تحميل الـ IPA خلال:";
        default: return "Preparing secure IPA download link in:";
      }
    } else {
      switch (lang) {
        case "ku_ba": return "پڕۆسێسا دامەزراندنا ڕاستەوخۆ دێ دەستپێکەت پشتی:";
        case "ku_so": return "پڕۆسەی دامەزراندنی ڕاستەوخۆ دەستپێدەکات دوای:";
        case "ar": return "جاري بدء التثبيت المباشر خلال ثوانٍ:";
        default: return "Starting secure direct installation in:";
      }
    }
  };

  const getCountdownSkipText = () => {
    if (countdownTriggerType === "ipa") {
      switch (lang) {
        case "ku_ba": return "دەربازکرنا چاڤەڕێکرنێ و داگرتن";
        case "ku_so": return "تێپەڕاندنی چاوەڕوانی و داگرتن";
        case "ar": return "تخطي الانتظار والتحميل المباشر";
        default: return "Skip Delay & Direct Download";
      }
    } else {
      switch (lang) {
        case "ku_ba": return "دەربازکرنا چاڤەڕێکرنێ و دامەزراندن";
        case "ku_so": return "تێپەڕاندنی چاوەڕوانی و دامەزراندن";
        case "ar": return "تخطي الانتظار والتثبيت الفوري";
        default: return "Skip Delay & Direct Install";
      }
    }
  };

  const startSigningProcess = (url: string) => {
    if (!url) return;
    
    if (signingIntervalRef.current) {
      clearInterval(signingIntervalRef.current);
    }

    // Start full screen signing simulation
    setInstallingState("connecting");
    setInstallProgress(10);
    
    const interval = setInterval(() => {
      setInstallProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          signingIntervalRef.current = null;
          setInstallingState("ready");
          
          // Execute prompt install after success view
          setTimeout(() => {
            window.location.href = url;
            // Reset to idle so they can do it again
            setInstallingState("idle");
          }, 1500);
          
          return 100;
        }
        
        let increment = 15;
        if (prev < 40) {
          setInstallingState("connecting");
          increment = 10;
        } else if (prev < 75) {
          setInstallingState("signing");
          increment = 15;
        } else {
          setInstallingState("manifesting");
          increment = 20;
        }
        return prev + increment;
      });
    }, 250);

    signingIntervalRef.current = interval;
  };

  const handleInstallClick = (url: string | undefined, triggerType: "ipa" | "install") => {
    if (!url) return;
    if (triggerType === "ipa") {
      window.open(url, "_blank");
    } else {
      startSigningProcess(url);
    }
  };

  const handleCopyKey = (keyText: string) => {
    navigator.clipboard.writeText(keyText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Find the trial key if defined in Kurdish texts
  const matchKey = app.updateLog.match(/[A-Z0-9]{10,20}/);
  const trialKey = matchKey ? matchKey[0] : null;

  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.95, y: 30 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      exit={{ opacity: 0, scale: 1.05, y: 40 }}
      transition={{ type: "spring", damping: 30, stiffness: 300 }}
      className={`fixed inset-0 z-[100] flex flex-col font-sans overflow-hidden ${isDarkMode ? 'bg-zinc-950 text-white' : 'bg-gray-50 text-gray-900'}`}
      dir={isRtl ? "rtl" : "ltr"}
    >
      {/* Dynamic Background Banner */}
      <div className="absolute top-0 left-0 right-0 h-[45vh] overflow-hidden pointer-events-none">
        <motion.img 
          initial={{ scale: 1.2, opacity: 0 }}
          animate={{ scale: 1, opacity: 0.22 }}
          transition={{ duration: 1 }}
          src={app.icon} 
          className="w-full h-full object-cover blur-[60px]" 
          referrerPolicy="no-referrer" 
        />
        <div className={`absolute inset-0 ${isDarkMode ? 'bg-gradient-to-b from-zinc-950/30 via-zinc-950/80 to-zinc-950' : 'bg-gradient-to-b from-white/30 via-white/80 to-gray-50'}`} />
      </div>

      {/* Header Navigation */}
      <div className="relative z-50 flex justify-between items-center p-6 pt-12">
        <motion.button 
          whileTap={{ scale: 0.9 }}
          onClick={onClose}
          className={`w-11 h-11 rounded-2xl flex items-center justify-center transition-all shadow-md backdrop-blur-xl border ${
            isDarkMode 
              ? 'bg-zinc-900/60 border-zinc-800/60 text-white' 
              : 'bg-white/75 border-gray-200/50 text-gray-900'
          }`}
        >
          <X size={20} strokeWidth={3} />
        </motion.button>
        <span className="text-xs font-black tracking-widest uppercase opacity-50 italic">{translate("aboutStore", lang)}</span>
        <a 
          href="https://t.me/RAkIRD1"
          target="_blank"
          rel="noopener noreferrer"
          className={`w-11 h-11 rounded-2xl flex items-center justify-center transition-all shadow-md backdrop-blur-xl border ${
            isDarkMode 
              ? 'bg-zinc-900/60 border-zinc-800/60 text-white' 
              : 'bg-white/75 border-gray-200/50 text-gray-900'
          }`}
        >
          <Send size={18} strokeWidth={3} />
        </a>
      </div>

      {/* Scrollable Content */}
      <div className="flex-1 overflow-y-auto px-6 md:px-8 pb-32 scrollbar-none relative z-10 pt-2">
        <div className="flex flex-col items-center">
          {/* Main Icon Area */}
          <motion.div 
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.1, type: "spring", damping: 20 }}
            className="relative mb-6 group cursor-help"
          >
            <div className="absolute inset-0 blur-[30px] rounded-[2.8rem] scale-110 opacity-35" style={{ backgroundColor: accentColor }} />
            <div className="relative p-1.5 rounded-[2.8rem] bg-gradient-to-br from-white/20 to-transparent border border-white/20 backdrop-blur-sm shadow-xl">
              <img 
                src={app.icon} 
                className="w-32 h-32 md:w-36 md:h-36 rounded-[2.4rem] shadow-md object-cover" 
                referrerPolicy="no-referrer"
              />
            </div>
          </motion.div>

          {/* Title & Stats */}
          <div className="text-center mb-8 w-full">
            <motion.h2 
              initial={{ y: 15, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.15 }}
              className="text-3xl md:text-4xl font-black tracking-tight mb-3 font-display italic leading-tight"
            >
              {app.name}
            </motion.h2>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.2 }}
              className="flex justify-center items-center gap-2.5"
            >
              <VerifiedBadge accentColor={accentColor} lang={lang} />
              <span className="w-1.5 h-1.5 rounded-full bg-zinc-300 dark:bg-zinc-800" />
              <p className="text-[10px] font-black tracking-widest uppercase opacity-40 italic">{app.category}</p>
            </motion.div>
          </div>

          {/* App Info Grid */}
          <motion.div 
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.25 }}
            className={`grid grid-cols-3 gap-0 w-full mb-8 py-5 rounded-[2.2rem] border overflow-hidden relative ${
              isDarkMode 
                ? 'bg-gradient-to-br from-zinc-900/40 to-zinc-950/60 border-zinc-800/50 backdrop-blur-md shadow-lg' 
                : 'bg-white/90 border-gray-100 shadow-sm backdrop-blur-md'
            }`}
          >
            <div className="flex flex-col items-center justify-center border-r border-zinc-200 dark:border-zinc-800/40 px-2 py-1">
              <span className="text-[8px] font-black uppercase tracking-wider opacity-40 mb-1.5 font-display">{translate("rating", lang)}</span>
              <div className="flex items-center gap-1">
                <span className="font-black text-lg italic tracking-tight leading-none">{app.rating}</span>
                <Star size={14} className="fill-current text-yellow-400" strokeWidth={3} />
              </div>
            </div>
            <div className="flex flex-col items-center justify-center border-r border-zinc-200 dark:border-zinc-800/40 px-2 py-1">
              <span className="text-[8px] font-black uppercase tracking-wider opacity-40 mb-1.5 font-display">{translate("size", lang)}</span>
              <span className="font-black text-lg italic tracking-tight leading-none">{app.size}</span>
            </div>
            <div className="flex flex-col items-center justify-center px-2 py-1">
              <span className="text-[8px] font-black uppercase tracking-wider opacity-40 mb-1.5 font-display">{translate("version", lang)}</span>
              <span className="font-black text-sm italic tracking-tight leading-none truncate max-w-[90px] text-center">{app.version}</span>
            </div>
          </motion.div>

          {/* Trial / Premium Key Clipboard helper */}
          {trialKey && (
            <motion.div
              initial={{ scale: 0.98, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className={`w-full mb-6 p-5 rounded-[2.2rem] border-2 border-dashed flex flex-col items-center text-center cursor-pointer transition-all duration-300 relative overflow-hidden group ${
                copied 
                  ? 'bg-emerald-500/10 border-emerald-500/40 text-emerald-400' 
                  : (isDarkMode ? 'bg-amber-500/5 border-amber-500/25 text-amber-400' : 'bg-amber-50/50 border-amber-200 text-amber-850')
              }`}
              onClick={() => handleCopyKey(trialKey)}
            >
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent shimmer-bg opacity-30 pointer-events-none" />
              <div className="flex items-center gap-2 mb-2 font-black text-xs uppercase tracking-widest">
                <Palette size={14} className="animate-pulse" />
                <span>{translate("clickCopy", lang)}</span>
              </div>
              <span className={`font-mono text-sm font-black px-5 py-1.5 rounded-xl bg-black/20 ${copied ? 'text-emerald-300' : 'text-amber-300'}`}>
                {trialKey}
              </span>
              {copied && <span className="text-[9px] font-black mt-2 uppercase tracking-wider text-emerald-400">{translate("copySuccess", lang)}</span>}
            </motion.div>
          )}

          {/* Sideload Signing Simulation Dialog */}
          {installingState !== "idle" && (
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className={`w-full mb-6 p-6 rounded-[2.2rem] border relative overflow-hidden ${
                isDarkMode ? 'bg-gradient-to-b from-zinc-900 to-zinc-950 border-zinc-800/60 shadow-2xl' : 'bg-white border-gray-100 shadow-xl'
              }`}
            >
              {/* Reset/Cancel Button */}
              <button 
                onClick={() => {
                  if (signingIntervalRef.current) {
                    clearInterval(signingIntervalRef.current);
                    signingIntervalRef.current = null;
                  }
                  setInstallingState("idle");
                  setInstallProgress(0);
                }}
                className={`absolute top-5 right-5 w-8 h-8 rounded-xl flex items-center justify-center border transition-all z-20 ${
                  isDarkMode 
                    ? 'bg-zinc-900/60 border-zinc-800/80 text-zinc-400 hover:text-white hover:bg-zinc-800/60' 
                    : 'bg-gray-50 border-gray-200/60 text-gray-500 hover:text-black hover:bg-gray-100'
                }`}
                title="Cancel"
              >
                <X size={14} strokeWidth={3} />
              </button>

              {/* Subtle background glow */}
              <div className="absolute -left-12 -bottom-12 w-32 h-32 rounded-full opacity-10 blur-xl" style={{ backgroundColor: accentColor }} />

              <div className="flex items-center justify-between mb-4 pr-10 relative z-10">
                <span className="text-[9px] font-black uppercase tracking-widest opacity-45">
                  {installProgress === 100 
                    ? translate("activeLabel", lang) 
                    : (countdownTriggerType === "ipa" 
                      ? (lang === "ku_ba" ? "داگرتنا بەرنامەی (Download IPA)" : lang === "ku_so" ? "داگرتنی بەرنامە (Download IPA)" : lang === "ar" ? "تحميل IPA" : "DOWNLOADING IPA")
                      : (lang === "ku_ba" ? "دامەزراندنا بەرنامەی (Installing)" : lang === "ku_so" ? "دامەزراندنی بەرنامە (Installing)" : lang === "ar" ? "تثبيت التطبيق" : "INSTALLING APP")
                    )}
                </span>
                <span className="text-sm font-mono font-black" style={{ color: accentColor }}>{installProgress}%</span>
              </div>
              
              {/* Progress Slider Bar */}
              <div className="w-full h-3 bg-zinc-200 dark:bg-zinc-800/50 rounded-full overflow-hidden mb-5 relative">
                <motion.div 
                  className="h-full rounded-full transition-all duration-300"
                  style={{ 
                    width: `${installProgress}%`, 
                    backgroundColor: accentColor,
                    boxShadow: `0 0 16px ${accentColor}`
                  }} 
                />
              </div>

              {/* Cryptographic Steps Live Tracker */}
              <div className="space-y-3 relative z-10 text-[11px] font-bold">
                <div className="flex items-center gap-2.5 text-emerald-400">
                  <Check size={14} className="stroke-[3.5] shrink-0" />
                  <span className="italic">
                    {lang === "ku_ba" ? "پەیوەندی دگەل سێرڤەری هاتە دروستکرن" : lang === "ku_so" ? "پەیوەندی لەگەڵ سێرڤەر دروستکرا" : lang === "ar" ? "تم الاتصال بالخادم الآمن بنجاح" : "Connection to secure server established"}
                  </span>
                </div>
                <div className={`flex items-center gap-2.5 transition-all ${installProgress >= 40 ? 'text-emerald-400' : 'opacity-40 text-zinc-400'}`}>
                  {installProgress >= 40 ? (
                    <Check size={14} className="stroke-[3.5] shrink-0" />
                  ) : (
                    <div className="w-3.5 h-3.5 rounded-full border-2 border-current border-t-transparent animate-spin shrink-0" />
                  )}
                  <span className="italic">
                    {countdownTriggerType === "ipa" 
                      ? (lang === "ku_ba" ? "داگرتنا فایلی IPA ب شێوەیەکێ پاراستی" : lang === "ku_so" ? "داگرتنی فایلی IPA بە شێوازێکی پارێزراو" : lang === "ar" ? "جاري تحميل ملف الـ IPA بشكل آمن..." : "Downloading IPA package from secure repository")
                      : (lang === "ku_ba" ? "ساینکرنا بەرنامەی ب باوەرناما فەرمی" : lang === "ku_so" ? "ساینکردنی بەرنامە بە بڕوانامەی فەرمی" : lang === "ar" ? "جاري توقيع حزمة التطبيق بالشهادة..." : "Signing installation bundle with enterprise cert")
                    }
                  </span>
                </div>
                <div className={`flex items-center gap-2.5 transition-all ${installProgress >= 85 ? 'text-emerald-400' : 'opacity-40 text-zinc-400'}`}>
                  {installProgress >= 85 ? (
                    <Check size={14} className="stroke-[3.5] shrink-0" />
                  ) : installProgress >= 40 ? (
                    <div className="w-3.5 h-3.5 rounded-full border-2 border-current border-t-transparent animate-spin shrink-0" />
                  ) : (
                    <div className="w-1.5 h-1.5 rounded-full bg-zinc-600 dark:bg-zinc-800 mx-1 shrink-0" />
                  )}
                  <span className="italic">
                    {countdownTriggerType === "ipa" 
                      ? (lang === "ku_ba" ? "پشکنینا دروستی و ئەولەهیا فایلی" : lang === "ku_so" ? "پشکنینی دروستی و ئەمنییەتی فایل" : lang === "ar" ? "تم إكمال التحميل والتحقق من سلامة الملف" : "Verifying IPA package signature and integrity")
                      : (lang === "ku_ba" ? "ئامادەکرنا لینکی بۆ دامەزراندنێ" : lang === "ku_so" ? "ئامادەکردنی لینک بۆ دامەزراندن" : lang === "ar" ? "جاري توليد رابط التثبيت المباشر الفوري..." : "Generating secure direct installation manifest")
                    }
                  </span>
                </div>
              </div>
            </motion.div>
          )}

          {/* Download Buttons Area */}
          <motion.div 
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.3 }}
            className="flex flex-col gap-4 w-full mb-8"
          >
            {app.ipaLink && (
              <button 
                onClick={() => handleInstallClick(app.ipaLink, "ipa")} 
                disabled={installingState !== "idle"}
                className="group relative w-full h-18 rounded-[2rem] flex items-center justify-center gap-3 overflow-hidden transition-all active:scale-[0.98] shadow-lg text-white"
                style={{ backgroundColor: accentColor, boxShadow: `0 12px 24px -6px ${accentColor}50` }}
              >
                <Download size={22} strokeWidth={3.5} className="relative z-10" />
                <span className="font-black text-lg font-display italic tracking-tight uppercase relative z-10">{translate("downloadIpa", lang)}</span>
                <motion.div 
                  animate={{ x: ["-100%", "200%"] }}
                  transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                  className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent w-full -skew-x-12"
                />
              </button>
            )}
            {app.directLink && (
              <button 
                onClick={() => handleInstallClick(app.directLink, "install")}
                disabled={installingState !== "idle"}
                className={`w-full h-16 rounded-[2rem] flex items-center justify-center gap-2.5 transition-all active:scale-[0.98] border-2 font-black text-base italic uppercase ${
                  isDarkMode 
                    ? 'bg-zinc-900 border-zinc-800 text-zinc-100 hover:bg-zinc-800/80' 
                    : 'bg-white border-gray-100 text-gray-900 shadow-sm hover:bg-gray-50'
                }`}
              >
                <ExternalLink size={18} strokeWidth={3.5} />
                <span>{translate("install", lang)}</span>
              </button>
            )}

            {/* Sideload Instruction Opener */}
            {app.platform === 'ios' && (
              <button
                onClick={() => setShowHowTo(!showHowTo)}
                className={`w-full py-4 text-xs font-black tracking-widest uppercase opacity-50 flex items-center justify-center gap-2 hover:opacity-100 transition-opacity`}
              >
                <Shield size={14} />
                <span>{translate("howToInstall", lang)}</span>
              </button>
            )}
          </motion.div>

          {/* Sideload Instruction Guide Drawer */}
          <AnimatePresence>
            {showHowTo && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                className="w-full overflow-hidden mb-8"
              >
                <div className={`p-6 rounded-[2.2rem] border ${
                  isDarkMode ? 'bg-zinc-900/40 border-zinc-800/60' : 'bg-gray-100/60 border-gray-200/50'
                }`}>
                  <h4 className="font-black text-sm mb-4 tracking-tight uppercase flex items-center gap-2">
                    <Info size={16} style={{ color: accentColor }} />
                    <span>{translate("stepsTitle", lang)}</span>
                  </h4>
                  <ul className="space-y-3.5 text-xs font-semibold opacity-90 leading-relaxed italic">
                    <li className="p-3 bg-black/10 rounded-xl">{translate("step1", lang)}</li>
                    <li className="p-3 bg-black/10 rounded-xl">{translate("step2", lang)}</li>
                    <li className="p-3 bg-black/10 rounded-xl">{translate("step3", lang)}</li>
                    <li className="p-3 bg-black/10 rounded-xl font-bold" style={{ color: accentColor }}>{translate("step4", lang)}</li>
                  </ul>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Warning Section */}
          {app.warning && (
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="w-full mb-8 p-6 rounded-[2.2rem] bg-red-500/10 border border-red-500/20 flex items-start gap-3.5"
            >
              <ShieldAlert className="text-red-500 shrink-0 mt-0.5" size={20} strokeWidth={3} />
              <p className="text-red-500 font-bold text-xs leading-relaxed italic">{app.warning}</p>
            </motion.div>
          )}

          {/* Content Details (Description) */}
          <motion.div 
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.4 }}
            className="w-full space-y-8"
          >
            <section>
              <div className="flex items-center gap-3 mb-4">
                <div className="w-8 h-8 rounded-xl flex items-center justify-center shadow-md" style={{ backgroundColor: `${accentColor}15`, color: accentColor }}>
                  <Info size={16} strokeWidth={3} />
                </div>
                <h4 className="font-black uppercase text-xs tracking-widest opacity-50">{translate("description", lang)}</h4>
              </div>
              <div className={`p-6 rounded-[2.2rem] border ${isDarkMode ? 'bg-zinc-900/20 border-zinc-800/40' : 'bg-white border-gray-100 shadow-sm'}`}>
                <p className={`text-base leading-relaxed font-semibold ${isDarkMode ? 'text-zinc-300' : 'text-gray-600'}`}>{app.description}</p>
              </div>
            </section>

            <section>
              <div className="flex items-center gap-3 mb-4">
                <div className="w-8 h-8 rounded-xl flex items-center justify-center shadow-md" style={{ backgroundColor: `${accentColor}15`, color: accentColor }}>
                  <History size={16} strokeWidth={3} />
                </div>
                <h4 className="font-black uppercase text-xs tracking-widest opacity-50">{translate("developerLogs", lang)}</h4>
              </div>
              <div className={`p-6 rounded-[2.2rem] border-2 border-dashed ${isDarkMode ? 'bg-zinc-900/10 border-zinc-800/40' : 'bg-gray-100/50 border-gray-200/60'}`}>
                <p className={`text-xs leading-relaxed font-bold italic whitespace-pre-wrap ${isDarkMode ? 'text-zinc-400' : 'text-gray-500'}`}>{app.updateLog}</p>
              </div>
            </section>

            {app.author && (
              <div className="flex items-center justify-between opacity-40 text-[10px] font-black uppercase tracking-widest px-2">
                <span>{translate("author", lang)}</span>
                <span>{app.author}</span>
              </div>
            )}
          </motion.div>
        </div>
      </div>

      {/* Interactive Premium Security Countdown Overlay */}
      <AnimatePresence>
        {countdownActive && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[150] flex items-center justify-center p-6 backdrop-blur-2xl bg-black/85"
          >
            {/* Ambient Background Glows */}
            <div className="absolute top-1/4 left-1/4 w-72 h-72 rounded-full opacity-20 blur-[100px]" style={{ backgroundColor: accentColor }} />
            <div className="absolute bottom-1/4 right-1/4 w-72 h-72 rounded-full opacity-10 blur-[100px]" style={{ backgroundColor: "#10b981" }} />

            <motion.div
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              transition={{ type: "spring", damping: 25, stiffness: 220 }}
              className={`w-full max-w-md p-8 rounded-[2.8rem] border shadow-2xl relative ${
                isDarkMode ? 'bg-zinc-950/80 border-zinc-800/80' : 'bg-white/95 border-gray-150'
              }`}
            >
              {/* Close Button to cancel countdown */}
              <button 
                onClick={() => setCountdownActive(false)}
                className={`absolute top-6 right-6 w-9 h-9 rounded-xl flex items-center justify-center border transition-all ${
                  isDarkMode 
                    ? 'bg-zinc-900/50 border-zinc-800 text-zinc-400 hover:text-white' 
                    : 'bg-gray-50 border-gray-200 text-gray-500 hover:text-black'
                }`}
              >
                <X size={16} strokeWidth={3} />
              </button>

              {/* Title & Badge */}
              <div className="flex flex-col items-center text-center mt-2 mb-6">
                <div className="w-14 h-14 rounded-2xl flex items-center justify-center mb-4 relative" style={{ backgroundColor: `${accentColor}15`, color: accentColor }}>
                  <div className="absolute inset-0 rounded-2xl animate-ping opacity-20" style={{ backgroundColor: accentColor }} />
                  <Shield size={26} strokeWidth={2.5} className="relative z-10 animate-pulse" />
                </div>
                <h3 className={`text-sm font-black uppercase tracking-widest leading-snug text-center ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                  {getCountdownTitle()}
                </h3>
                <span className={`text-[9px] font-bold px-3 py-1 rounded-full mt-2 inline-block ${
                  isDarkMode ? 'bg-zinc-900 text-zinc-500' : 'bg-gray-100 text-gray-400'
                }`}>
                  BYPASS SECURE GATEWAY
                </span>
              </div>

              {/* Circular Interactive Timer */}
              <div className="relative w-44 h-44 mx-auto mb-8 mt-4 flex items-center justify-center">
                <svg className="absolute inset-0 w-full h-full -rotate-90">
                  <circle 
                    cx="88" 
                    cy="88" 
                    r="72" 
                    className="stroke-zinc-200 dark:stroke-zinc-800/60 fill-none" 
                    strokeWidth="10" 
                  />
                  <motion.circle 
                    cx="88" 
                    cy="88" 
                    r="72" 
                    className="fill-none"
                    stroke={accentColor}
                    strokeWidth="10" 
                    strokeLinecap="round"
                    strokeDasharray={2 * Math.PI * 72}
                    animate={{
                      strokeDashoffset: (2 * Math.PI * 72) * (1 - countdownSeconds / countdownTotal)
                    }}
                    transition={{ duration: 0.3 }}
                  />
                </svg>
                <div className="text-center">
                  <span className="text-5xl font-black font-mono tracking-tight" style={{ color: accentColor }}>
                    {countdownSeconds}
                  </span>
                  <p className="text-[8px] font-black uppercase tracking-widest opacity-40 mt-1">
                    {translate("secondsRemaining", lang)}
                  </p>
                </div>
              </div>

              {/* Progress Text Description */}
              <p className={`text-center text-xs font-semibold px-4 mb-8 leading-relaxed ${isDarkMode ? 'text-zinc-400' : 'text-gray-600'}`}>
                {getCountdownLabel()}
              </p>

              {/* Skip and direct download button */}
              <button
                onClick={() => {
                  setCountdownActive(false);
                  startSigningProcess(countdownTargetUrl);
                }}
                className={`w-full py-4 rounded-2xl flex items-center justify-center gap-2 font-black text-xs uppercase tracking-wider transition-all active:scale-95 border ${
                  isDarkMode 
                    ? 'bg-zinc-900 border-zinc-800 text-zinc-300 hover:bg-zinc-800 hover:text-white' 
                    : 'bg-gray-50 border-gray-200 text-gray-700 hover:bg-gray-100'
                }`}
              >
                <Zap size={14} style={{ color: accentColor }} className="animate-pulse" />
                <span>{getCountdownSkipText()}</span>
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};

const AppView = ({ isDarkMode, accentColor, onSelectApp, platform = 'ios', lang }: { isDarkMode: boolean, accentColor: string, onSelectApp: (app: AppItem) => void, platform?: 'ios' | 'android', lang: Language, key?: React.Key }) => {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");

  const categories = ["All", "Games", "Media"];
  const isRtl = lang !== "en";

  const filteredApps = APPS.filter(app => {
    const matchesPlatform = app.platform === platform;
    const matchesSearch = app.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                         app.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === "All" || app.category === selectedCategory;
    return matchesPlatform && matchesSearch && matchesCategory;
  });

  return (
    <ViewContainer>
      <SectionHeader title={platform === 'ios' ? "iPhone iOS Apps" : "Android APK Store"} isDarkMode={isDarkMode} />
      
      {/* Visual Elegant Search Box */}
      <StaggerItem className="relative mb-6 group">
        <Search className={`absolute ${isRtl ? 'right-5' : 'left-5'} top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-zinc-500 transition-all`} size={18} strokeWidth={3} />
        <input 
          type="text" 
          placeholder={translate("searchPlaceholder", lang)} 
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className={`w-full border-2 rounded-2xl py-5 text-[15px] font-bold transition-all outline-none ${
            isRtl ? 'pr-14 pl-8' : 'pl-14 pr-8'
          } ${
            isDarkMode 
              ? 'bg-zinc-900/50 border-zinc-800/60 text-white placeholder:text-zinc-700 focus:border-zinc-700 focus:bg-zinc-900/80' 
              : 'bg-white border-gray-100 text-gray-900 shadow-sm focus:border-gray-200 focus:bg-gray-50/50'
          }`}
          style={{ '--tw-ring-color': `${accentColor}20` } as any}
        />
      </StaggerItem>

      {/* Horizontal Category Sorter pills */}
      <StaggerItem className="flex gap-2 mb-8 overflow-x-auto pb-2 scrollbar-none px-1">
        {categories.map((cat) => {
          const categoryTranslated = cat === "All" ? translate("all", lang) : (cat === "Games" ? translate("games", lang) : translate("media", lang));
          const isActive = selectedCategory === cat;
          return (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-6 py-3 rounded-xl text-[9px] font-black uppercase tracking-[0.15em] transition-all active:scale-95 whitespace-nowrap ${
                isActive
                  ? 'text-white shadow-md'
                  : (isDarkMode ? 'bg-zinc-900/60 border border-zinc-800/40 text-zinc-500 hover:text-zinc-300' : 'bg-white border border-gray-100 text-gray-450 hover:bg-gray-50 shadow-sm')
              }`}
              style={{ backgroundColor: isActive ? accentColor : undefined }}
            >
              {categoryTranslated}
            </button>
          );
        })}
      </StaggerItem>

      {/* Main Filtered Apps Rows */}
      <div className="space-y-4">
        {filteredApps.length > 0 ? (
          filteredApps.map((app) => (
            <StaggerItem key={app.id}>
              <Card 
                isDarkMode={isDarkMode} 
                className={`flex items-center gap-4 cursor-pointer hover:scale-[1.01] active:scale-[0.99] transition-all group p-4 border border-transparent ${
                  isDarkMode 
                    ? 'hover:border-zinc-800/80 bg-zinc-900/20 shadow-lg' 
                    : 'hover:border-gray-200/80 bg-white shadow-sm'
                }`}
              >
                <div onClick={() => onSelectApp(app)} className="flex items-center justify-between w-full gap-4">
                  <div className="flex items-center gap-4 flex-1 min-w-0">
                    <div className="w-20 h-20 rounded-[1.8rem] overflow-hidden shadow-md transition-all duration-350 group-hover:rotate-1 group-hover:scale-103 shrink-0">
                      <img src={app.icon} alt={app.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1.5 mb-1.5">
                         <VerifiedBadge accentColor={accentColor} lang={lang} />
                      </div>
                      <p className={`font-black tracking-tight text-lg mb-1 leading-tight italic font-display transition-colors ${
                        isDarkMode ? 'text-white group-hover:text-zinc-100' : 'text-gray-900 group-hover:text-black'
                      }`}>{app.name}</p>
                      <div className="flex items-center gap-2">
                        <span className={`text-[9px] font-black uppercase tracking-wider px-2 py-0.5 rounded-lg ${isDarkMode ? 'bg-zinc-900 text-zinc-500' : 'bg-gray-50 text-gray-400'}`}>{app.category}</span>
                        <span className="w-1 h-1 rounded-full bg-zinc-300 dark:bg-zinc-800" />
                        <span className={`text-[9px] font-bold opacity-30 tracking-wider`}>{app.size}</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all ${
                    isDarkMode ? 'bg-zinc-900/85 border border-zinc-800 text-zinc-500 group-hover:border-zinc-700 group-hover:text-zinc-300' : 'bg-gray-50 border border-gray-100 text-gray-400 group-hover:bg-gray-100'
                  } shrink-0`}>
                    <ChevronRight size={18} strokeWidth={3} className={`transition-transform group-hover:translate-x-0.5 ${isRtl ? "rotate-180 group-hover:-translate-x-0.5" : ""}`} />
                  </div>
                </div>
              </Card>
            </StaggerItem>
          ))
        ) : (
          <StaggerItem className="py-20 text-center">
            <Search size={54} strokeWidth={1} className="mx-auto mb-4 opacity-5 text-current animate-pulse" />
            <p className="text-[10px] font-black uppercase tracking-[0.3em] opacity-20 font-display italic">Storefront Empty</p>
          </StaggerItem>
        )}
      </div>
    </ViewContainer>
  );
};

const SettingView = ({ state, setState }: { state: AppState, setState: React.Dispatch<React.SetStateAction<AppState>>, key?: React.Key }) => {
  const languages = [
    { id: "ku_ba", label: "Badini (بەدینی)" },
    { id: "ku_so", label: "Sorani (سۆرانی)" },
    { id: "en", label: "English" },
    { id: "ar", label: "العربية" },
  ];

  const colors = [
    "#ef4444", // Red
    "#3b82f6", // Blue
    "#10b981", // Green
    "#8b5cf6", // Purple
    "#f59e0b", // Amber
    "#06b6d4", // Cyan
  ];

  const lang = state.language;

  return (
    <ViewContainer>
      <StaggerItem className="flex flex-col items-center mb-10 px-1">
        <div className="relative group mb-6">
          <div className="absolute inset-0 blur-[24px] rounded-full opacity-30" style={{ backgroundColor: state.accentColor }} />
          <div className="w-28 h-28 rounded-[2.8rem] overflow-hidden shadow-xl border-4 border-white dark:border-zinc-900 transition-transform duration-700 group-hover:rotate-2">
            <img src={LOGO_URL} alt="Profile" className="w-full h-full object-cover" />
          </div>
          <div className="absolute -bottom-1 -right-1 w-9 h-9 rounded-xl bg-blue-500 border-4 border-white dark:border-zinc-950 flex items-center justify-center text-white shadow-md">
            <Check size={16} strokeWidth={4} />
          </div>
        </div>
        <h3 className={`text-2xl font-black tracking-tight font-display mb-0.5 ${state.isDarkMode ? 'text-white' : 'text-gray-900'}`}>{translate("developerName", lang)}</h3>
        <p className="font-black tracking-[0.3em] text-[9px] uppercase opacity-40">{translate("founder", lang)}</p>
      </StaggerItem>

      <SectionHeader title={translate("customization", lang)} isDarkMode={state.isDarkMode} />
      
      <div className="space-y-6">
        <Card isDarkMode={state.isDarkMode} className="p-0 overflow-hidden divide-y divide-gray-50/50 dark:divide-zinc-800/40 border-none shadow-xl">
          {/* Dark Mode switcher */}
          <StaggerItem>
            <div 
              onClick={() => setState(prev => ({ ...prev, isDarkMode: !prev.isDarkMode }))}
              className="flex items-center gap-4 p-6 hover:bg-gray-50 dark:hover:bg-zinc-900/20 cursor-pointer transition-all active:bg-zinc-100 dark:active:bg-zinc-900"
            >
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all ${state.isDarkMode ? 'bg-amber-400/10 text-amber-400' : 'bg-zinc-100 text-gray-500'}`}>
                {state.isDarkMode ? <Sun size={20} strokeWidth={2.5} /> : <Moon size={20} strokeWidth={2.5} />}
              </div>
              <div className={`flex-1 font-black text-xs uppercase tracking-wider ${state.isDarkMode ? 'text-zinc-200' : 'text-gray-700'}`}>{translate("appearance", lang)}</div>
              <div className="w-12 h-7 rounded-full bg-zinc-200 dark:bg-zinc-800 relative p-1 transition-colors" style={{ backgroundColor: state.isDarkMode ? state.accentColor : undefined }}>
                <motion.div 
                  animate={{ x: state.isDarkMode ? 20 : 0 }}
                  className="w-5 h-5 rounded-full bg-white shadow-md"
                  transition={{ type: "spring", stiffness: 500, damping: 30 }}
                />
              </div>
            </div>
          </StaggerItem>

          {/* Accent Palette selection */}
          <StaggerItem className="p-6">
            <div className="flex items-center gap-4 mb-5">
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${state.isDarkMode ? 'bg-zinc-900 text-white' : 'bg-zinc-100 text-gray-500'}`}>
                <Palette size={20} strokeWidth={2.5} />
              </div>
              <div className={`flex-1 font-black text-xs uppercase tracking-wider ${state.isDarkMode ? 'text-zinc-200' : 'text-gray-700'}`}>{translate("brandSignature", lang)}</div>
            </div>
            <div className="flex flex-wrap gap-3.5 px-1 justify-center">
              {colors.map((color) => (
                <button
                  key={color}
                  onClick={() => setState(prev => ({ ...prev, accentColor: color }))}
                  className={`w-10 h-10 rounded-xl transition-all active:scale-90 flex items-center justify-center relative ${
                    state.accentColor === color ? 'scale-105' : 'opacity-40 hover:opacity-100'
                  }`}
                  style={{ backgroundColor: color }}
                >
                  {state.accentColor === color && (
                    <motion.div layoutId="colorCheck" className="text-white">
                      <Check size={18} strokeWidth={4} />
                    </motion.div>
                  )}
                </button>
              ))}
            </div>
          </StaggerItem>

          {/* Localization switch */}
          <StaggerItem className="p-6">
            <div className="flex items-center gap-4 mb-5">
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${state.isDarkMode ? 'bg-zinc-900' : 'bg-zinc-100'}`}>
                <Globe size={20} strokeWidth={2.5} />
              </div>
              <div className={`flex-1 font-black text-xs uppercase tracking-wider ${state.isDarkMode ? 'text-zinc-200' : 'text-gray-700'}`}>{translate("storeLocalization", lang)}</div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              {languages.map((l) => (
                <button
                  key={l.id}
                  onClick={() => setState(prev => ({ ...prev, language: l.id as Language }))}
                  className={`flex items-center justify-between p-4 rounded-xl text-[9px] font-black uppercase tracking-wider transition-all active:scale-95 border-2 ${
                    state.language === l.id 
                      ? 'text-white border-transparent' 
                      : (state.isDarkMode ? 'bg-zinc-900 border-zinc-800 text-zinc-500 hover:text-zinc-300' : 'bg-white border-gray-100 text-gray-400 hover:bg-gray-50 shadow-sm')
                  }`}
                  style={{ backgroundColor: state.language === l.id ? state.accentColor : undefined }}
                >
                  {l.label}
                  {state.language === l.id && <Check size={12} strokeWidth={4} />}
                </button>
              ))}
            </div>
          </StaggerItem>
        </Card>

        {/* Official Links Feed */}
        <SectionHeader title={translate("officialFeed", lang)} isDarkMode={state.isDarkMode} />
        <div className="grid grid-cols-2 gap-4">
          <StaggerItem>
            <a 
              href="https://t.me/RAkIRD1" 
              target="_blank" 
              rel="noopener noreferrer" 
              className={`flex flex-col items-center gap-3.5 p-6 rounded-[2.2rem] font-black transition-all active:scale-95 group overflow-hidden ${
                state.isDarkMode ? 'bg-zinc-900 border border-zinc-800 text-white shadow-md' : 'bg-white border border-gray-100 text-gray-900 shadow-sm'
              }`}
            >
              <div className="w-12 h-12 rounded-xl bg-blue-500 flex items-center justify-center text-white shadow-lg transition-transform group-hover:scale-105 shrink-0">
                <Send size={20} strokeWidth={2.5} />
              </div>
              <div className="text-center">
                <span className="text-[8px] uppercase tracking-widest opacity-45 block mb-0.5">Telegram</span>
                <span className="text-xs font-display italic tracking-tight">Channel</span>
              </div>
            </a>
          </StaggerItem>

          <StaggerItem>
            <a 
              href="https://www.instagram.com/ra_kurd.store?igsh=MWxiZTVxdG55MnNwNw%3D%3D&utm_source=qr" 
              target="_blank" 
              rel="noopener noreferrer" 
              className={`flex flex-col items-center gap-3.5 p-6 rounded-[2.2rem] font-black transition-all active:scale-95 group overflow-hidden ${
                state.isDarkMode ? 'bg-zinc-900 border border-zinc-800 text-white shadow-md' : 'bg-white border border-gray-100 text-gray-900 shadow-sm'
              }`}
            >
              <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-yellow-400 via-pink-500 to-purple-600 flex items-center justify-center text-white shadow-lg transition-transform group-hover:scale-105 shrink-0">
                <Instagram size={20} strokeWidth={2.5} />
              </div>
              <div className="text-center">
                <span className="text-[8px] uppercase tracking-widest opacity-45 block mb-0.5">Instagram</span>
                <span className="text-xs font-display italic tracking-tight">Profile</span>
              </div>
            </a>
          </StaggerItem>
        </div>

        {/* Footer Credit Tag */}
        <div className="flex flex-col items-center pt-16 pb-6 opacity-30">
          <img src={LOGO_URL} className="w-12 h-12 grayscale opacity-70 mb-4 rounded-xl" alt="Logo Watermark" />
          <div className="text-center">
            <p className={`text-[9px] font-black tracking-widest uppercase mb-0.5 ${state.isDarkMode ? 'text-zinc-500' : 'text-gray-400'}`}>RA KURD STORE</p>
            <p className="text-[7px] font-black tracking-wider uppercase opacity-45 leading-none">BUILD 2.0.0 • PROFESSIONAL COSMIC EDITION</p>
          </div>
        </div>
      </div>
    </ViewContainer>
  );
};

// --- Main App ---

export default function App() {
  const [activeTab, setActiveTab] = useState<Tab>("home");
  const [selectedApp, setSelectedApp] = useState<AppItem | null>(null);
  const [isSignerOpen, setIsSignerOpen] = useState(false);
  const [appState, setAppState] = useState<AppState>({
    isDarkMode: true, // Defaulting to TRUE for highly premium dark aesthetic look!
    language: "ku_ba", // Default to Kurdish Badini as requested previously
    accentColor: "#3b82f6", // Premium default royal blue accent
  });

  useEffect(() => {
    if (appState.isDarkMode) {
      document.body.classList.add('bg-zinc-950');
      document.body.classList.remove('bg-gray-50');
    } else {
      document.body.classList.add('bg-gray-50');
      document.body.classList.remove('bg-zinc-950');
    }
  }, [appState.isDarkMode]);

  useEffect(() => {
    // Disable context menu and specific security shortcuts
    const handleContextMenu = (e: MouseEvent) => {
      e.preventDefault();
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      if (
        (e.ctrlKey && (e.key === 'c' || e.key === 'v' || e.key === 'u' || e.key === 's' || e.key === 'a')) ||
        e.key === 'F12' ||
        (e.metaKey && (e.key === 'c' || e.key === 'v' || e.key === 'u' || e.key === 's' || e.key === 'a'))
      ) {
        e.preventDefault();
      }
    };

    document.addEventListener('contextmenu', handleContextMenu);
    document.addEventListener('keydown', handleKeyDown);

    return () => {
      document.removeEventListener('contextmenu', handleContextMenu);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, []);

  const navItems: { id: Tab; label: string; icon: typeof Home }[] = [
    { id: "home", label: "Home", icon: Home },
    { id: "ios", label: "iPhone", icon: Apple },
    { id: "apk", label: "Android", icon: Bot },
    { id: "setting", label: "Setting", icon: Settings },
  ];

  const isRtl = appState.language !== "en";

  return (
    <div 
      className={`min-h-screen transition-all duration-700 relative overflow-hidden ${
        appState.isDarkMode ? 'bg-zinc-950 text-white' : 'bg-gray-50 text-gray-900'
      } selection:bg-gray-200 selection:text-black`}
      dir={isRtl ? "rtl" : "ltr"}
    >
      {/* Background Soft Ambient Light Blurs (Cosmic Theme) */}
      {appState.isDarkMode && (
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-lg h-[500px] overflow-hidden pointer-events-none z-[-10]">
          <div className="absolute top-[-25%] left-[-20%] w-[90%] h-[90%] rounded-full opacity-20 blur-[120px]" style={{ backgroundColor: appState.accentColor }} />
          <div className="absolute top-[15%] right-[-15%] w-[70%] h-[70%] rounded-full opacity-10 blur-[100px] bg-indigo-500" />
        </div>
      )}

      {/* Main Content Area */}
      <div className="relative flex flex-col min-h-screen overflow-x-hidden">
        <AnimatePresence mode="wait">
          {activeTab === "home" && <HomeView isDarkMode={appState.isDarkMode} accentColor={appState.accentColor} onSelectApp={setSelectedApp} lang={appState.language} key="home" onSignerToggle={setIsSignerOpen} />}
          {activeTab === "ios" && <AppView isDarkMode={appState.isDarkMode} accentColor={appState.accentColor} onSelectApp={setSelectedApp} lang={appState.language} key="ios" platform="ios" />}
          {activeTab === "apk" && <AppView isDarkMode={appState.isDarkMode} accentColor={appState.accentColor} onSelectApp={setSelectedApp} lang={appState.language} key="apk" platform="android" />}
          {activeTab === "setting" && <SettingView state={appState} setState={setAppState} key="setting" />}
        </AnimatePresence>
      </div>

      {/* Navigation Bar */}
      <nav className="fixed bottom-0 left-0 right-0 z-50">
        <div className="max-w-lg mx-auto px-8 pt-2" style={{ paddingBottom: 'calc(env(safe-area-inset-bottom, 0px) + 24px)' }}>
          <div className={`backdrop-blur-3xl border shadow-lg rounded-[4rem] flex items-center justify-between px-6 py-5 transition-all duration-700 ${
            appState.isDarkMode ? 'bg-zinc-900/85 border-zinc-800/60 shadow-black/40' : 'bg-white/85 border-white/50'
          }`}>
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className="relative flex flex-col items-center justify-center flex-1 outline-none group"
                >
                  <div className={`relative z-10 transition-all duration-500 ${isActive ? 'scale-110 -translate-y-1' : 'scale-100 group-hover:scale-105 active:scale-90 opacity-40 group-hover:opacity-100'}`}>
                    <Icon 
                      size={24} 
                      className="transition-colors duration-500" 
                      style={{ color: isActive ? appState.accentColor : (appState.isDarkMode ? '#ffffff' : '#000000') }}
                      strokeWidth={isActive ? 3 : 2}
                    />
                  </div>
                  
                  {isActive && (
                    <motion.div
                      layoutId="activeTabIndicator"
                      className="absolute -bottom-3 w-1.5 h-1.5 rounded-full"
                      style={{ backgroundColor: appState.accentColor }}
                      transition={{ type: "spring", bounce: 0.3, duration: 0.6 }}
                    />
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </nav>

      {/* Full screen Detail Overlay */}
      <AnimatePresence>
        {selectedApp && (
          <AppDetailView 
            app={selectedApp} 
            onClose={() => setSelectedApp(null)} 
            accentColor={appState.accentColor} 
            isDarkMode={appState.isDarkMode} 
            lang={appState.language}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
